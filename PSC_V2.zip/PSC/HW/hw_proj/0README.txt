/* 0README.txt
 * Edel D�az Llerena
 * Universidad de Alcal�
 * 06/11/2018
 */
##
## Organizaci�n del repositorio:
##
  /HDF_BIT --> carpeta donde estan los ficheros .hdf y .bit creados a 
    partir del proyecto de Vivado para la generaci�n del Sistema Operativo
    con Petalinux.

##
## Proyecto Vivado:
##
Para generar el proyecto seguir los siguientes pasos:
0. Respetar la organizaci�n del directorio.
1. Modificar el path del proyecto en el archivo run_prj.tcl 
      set hw_prj_path {YOUR PATH TO HW_PROJ}
2. Abrir Vivado 2017.4
3. Tools>Run Tcl Script..
4. Seleccionar run_prj.tcl

Se debe generar el proyecto.
