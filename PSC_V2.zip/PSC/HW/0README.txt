/* 0README.txt
 * Edel D�az Llerena
 * Universidad de Alcal�
 * 06/11/2018
 */
##
## Organizaci�n del repositorio:
##
  /hw_repo --> carpeta donde est�n los IPs a medida para el proyecto.
  /hw_proj --> carpeta donde est� el proyecto de Vivado y ficheros .hdf y .bit