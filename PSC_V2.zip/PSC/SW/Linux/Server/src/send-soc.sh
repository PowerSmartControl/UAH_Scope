#!/bin/bash
###############
# Edel Díaz Llerena
# University of Alcala
# 26/10/2018
###############
# Description: File to send Server to SoC via SSH
###############
clear
set -e

# limpiar las claves SSH
> /home/edel.diaz/.ssh/known_hosts
file_in=./server-soc
file_out=/home/root
user=root
host=192.168.75.165
scp -r $file_in $user@$host:$file_out

