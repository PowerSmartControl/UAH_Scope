/*  socket_psc.h - socket definitions
******************
* Edel Diaz Llerena
* 09/11/2018
* University of Alcala
******************
* Description:
* This file set the library to use socket and defines others types.
******************
* Change log:
* v1.0 - Version Stable.
******************
* Version:
* 1.0
******************
*/
#ifndef SOCKET_PSC_H
#define SOCKET_PSC_H
#ifdef __linux__
  #include <unistd.h>
  #include <stdio.h>
  #include <sys/socket.h>
  #include <sys/ioctl.h>
  #include <sys/time.h>
  #include <fcntl.h>
  #include <stdlib.h>
  #include <netinet/in.h>
  #include <string.h>
  #include <pthread.h>
  #include <errno.h>
  #include <netdb.h>
  #include <arpa/inet.h>
  #include <net/if.h>
#elif _WIN32
  #include <winsock2.h>
  #include <ws2tcpip.h>
  #include <windows.h>
  #include <stdint.h>
#endif

#include "common.h"

typedef uint32_t fifo_data_t;                      // Size of word

typedef struct net
{ //TCP
#ifdef __linux__
  int new_socket;                                  // Id socket
  struct sockaddr_in sockaddr_str;                 // Socket struct
#elif _WIN32
  SOCKET new_socket;                               // Id socket
  SOCKADDR_IN sockaddr_str;                        // Socket struct
#endif
  int valread;                                     // Bytes read
  int valsend;                                     // Bytes to send
  fifo_data_t rx_buffer[SIZE_BUFFER_LONG * 2];     // Input buffer
  fifo_data_t wx_buffer[SIZE_BUFFER_LONG * 2];     // Output buffer    
  fifo_data_t hello;                               // HelloWorld msg 
  //Protocol
  unsigned int magic_num;                          // MAGIC_NUM CMD (command)
  unsigned int cmd_us;                             // CMD_US CMD 
  unsigned int cmd_ldd;                            // CMD_LDD CMD 
  unsigned int param;                              // PARAM CMD 
  fifo_data_t cmd_full;                            // All CMD
  fifo_data_t value_reg;                           // Value to write/read 
  int streaming_mode;                              // 1 if streaming mode. 0 if not streaming mode. 
} net_t;

#define readn(fd, ptr, n) recv(fd, ptr, n, FLAG_READ)   

#endif
