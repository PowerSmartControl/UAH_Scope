/* server.c - Application for server
 ******************
 * Edel Diaz Llerena
 * 02/10/2018
 * University of Alcala
 ******************
 * Description:
 * Top of server
 ******************
 * Change log:
 * v1.0 - Version Stable.
 * v1.1 - Included SOC #define and error management.
 * v1.2 - Included semaphore to speed-up performance and management of errors.
 * v2.0 - Updated.
 ******************
 * Version:
 * 2.0
 ******************
 */
#define  VERSION 2.0

// Server side C/C++ program to demonstrate Socket programming
#include "socket_psc.h"
#include  <semaphore.h>

/***********************To compiler***********************/
//#define DEBUG      // Disable to not show printfs
//#define SOC        // Disable to Linux test

#ifdef DEBUG
 #define dbg_printf(...)	\
	printf(__VA_ARGS__);
#else
 #define dbg_printf(...)
#endif

#ifdef SOC
  #define LDD_PATH "/dev/psc-lddDevice"
#else
  #define LDD_PATH "../input_files/test_ldd.bin"
#endif

/*********************** DEFINES ***********************/

#define PORT 54000 //any port that is free from 1024 to 65635
/* It specifies the maximum number of client connections that the kernel will
queue for the listening descriptor.
*/

#define LISTENQ 3// number of client to connect
#define FIFO_SIZE    SIZE_PAYLOAD_LONG*2 //TODO el doble
#define TRUE 1

/*********************** GLOBAL VARIABLES ***********************/

/*  int fd_log;
int fd_log2;
int ret2;
int ret3;*/

sem_t sem_global;

//Global variables to LDD thread
int State_thread, run_thread, sem_read, fd_ldd;
pthread_mutex_t pthread_mutex = PTHREAD_MUTEX_INITIALIZER;

unsigned int errorc;
/*********************** GLOBAL STRUCTS ***********************/
/* Struct for FIFO
 */
typedef struct fifo {
	uint32_t          rd_idx;
	uint32_t          wr_idx;
	uint32_t          cnt;
	fifo_data_t       data[SIZE_PAYLOAD_LONG*2];
}fifo_t;

static fifo_t fifo_str;

/* Thread struct
 */
net_t net_str;

#include <sys/time.h>
long long mil_anterior;

static long long current_timestamp(long long mil_anterior) {
    struct timeval te;
    gettimeofday(&te, NULL); // get current time
    long long milliseconds = te.tv_sec*1000LL + te.tv_usec/1000; // calculate milliseconds
    printf(//"milliseconds: %lld\n"
           //"mil_anterior: %lld\n"
           "milliseconds-mil_anterior:  %lld\n",
           // milliseconds,
           // mil_anterior,
            milliseconds-mil_anterior);
    return milliseconds;
}


/* This function is called when init LDD thread. It inits fifo.
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
static int fifo_init(fifo_t *q) {
  q->rd_idx = q->wr_idx = 0;
  q->cnt = 0;
  return 0;
}

/* This function is called in STREAMING_STATE_MAIN.
 * It is used for test if there are data into fifo.
 * @param *q - A pointer to fifo struct.
 * @return - It returns 1 if fifo is empty
 */
static int fifo_empty(fifo_t *q) {
  int ret, s;
  s = pthread_mutex_lock(&pthread_mutex);
  if (s != 0){
	  printf("***SERVER ERROR***: %s: phtread_mutex_lock error :%i\n", __func__, s);
    return -1;
  }

  ret = (q->cnt == 0);

  s = pthread_mutex_unlock(&pthread_mutex);
  if (s != 0){
    printf("***SERVER ERROR***: %s: phtread_mutex_unlock error :%i\n", __func__, s);
    return -1;
  }
  return ret;
}

/* This function is called in STREAMING_STATE_MAIN.
 * It is used for test how many data there are into fifo.
 * @param *q - A pointer to fifo struct.
 * @return - It returns number of events into fifo.
 */
static int fifo_count(fifo_t *q) {
  int ret, s;
  s = pthread_mutex_lock(&pthread_mutex);
  if (s != 0){
	  printf("***SERVER ERROR***: %s: phtread_mutex_lock error :%i\n", __func__, s);
    return -1;
  }

  ret = q->cnt;

  s = pthread_mutex_unlock(&pthread_mutex);
  if (s != 0){
    printf("***SERVER ERROR***: %s: phtread_mutex_unlock error :%i\n", __func__, s);
    return -1;
  }
  return ret;
}

/* This function is called in STREAMING_STATE_MAIN whenever it reads fifo from
 * main thread.
 * @param *q - A pointer to fifo struct.
 * @param *data - A pointer to buffer to read from user space. Typically uint32_t.
 * @return - It returns 0 if successful.
 */
static int fifo_get(fifo_t *q, fifo_data_t *data) {
  int ret, s;
  s = pthread_mutex_lock(&pthread_mutex);
  if (s != 0){
	  printf("***SERVER ERROR***: %s: phtread_mutex_lock error :%i\n", __func__, s);
    return -1;
  }

  if(q->cnt != 0) {
    *data = q->data[q->rd_idx];
    q->rd_idx = (q->rd_idx == FIFO_SIZE-1)? 0 : q->rd_idx + 1;
    q->cnt--;
    ret = 1;
  }
  else {
    *data = 0;
    ret = 0;
  }
  //printf("SERVER: %s: READ cnt = %i, rd_idx = %i.\n",__func__ , q->cnt, q->rd_idx);

  s = pthread_mutex_unlock(&pthread_mutex);
  if (s != 0){
    printf("***SERVER ERROR***: %s: phtread_mutex_unlock error :%i\n", __func__, s);
    return -1;
  }
  return ret;
}

/* This safe function is called in READ_FROM_LDD_THREAD whenever an LDD reading
 * occurs. It copies readed data from LDD into fifo. It also increases wr_idx
 * and cnt indexes.
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
static int fifo_put(fifo_t *q, fifo_data_t *DataFromLDD, int len) {
  int ret, s, i;
  s = pthread_mutex_lock(&pthread_mutex);
  if (s != 0){
	  printf("***SERVER ERROR***: %s: phtread_mutex_lock error :%i\n", __func__, s);
    return -1;
  }

  for (i = 0; i < len; i++ ) {
    if(q->cnt < FIFO_SIZE) {
      q->data[q->wr_idx] = DataFromLDD[i];// here is the difference
      q->wr_idx = (q->wr_idx == FIFO_SIZE-1)? 0 : q->wr_idx + 1;
      q->cnt++;
      ret = 1;
    } else {
      printf("***SERVER WARNING*** %s: fifo overflow\n", __func__);
      ret = -1;
    }
  }

  s = pthread_mutex_unlock(&pthread_mutex);
  if (s != 0){
    printf("***SERVER ERROR***: %s: phtread_mutex_unlock error :%i\n", __func__, s);
    return -1;
  }
  return ret;
}

/* This safe function is called in READ_FROM_LDD_THREAD whenever an LDD reading
 * occurs. It copies readed data from LDD into fifo. It also increases wr_idx
 * and cnt indexes. Only one time.
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
static int fifo_put_int(fifo_t *q, fifo_data_t DataFromLDD, int len) {
  int ret, s;
  s = pthread_mutex_lock(&pthread_mutex);
  if (s != 0){
	  printf("***SERVER ERROR***: %s: phtread_mutex_lock error :%i\n", __func__, s);
    return -1;
  }

  if(q->cnt < FIFO_SIZE) {
    q->data[q->wr_idx] = DataFromLDD;// here is the difference
    q->wr_idx = (q->wr_idx == FIFO_SIZE-1)? 0 : q->wr_idx + 1;
    q->cnt++;
    ret = 1;
  } else {
    printf("SERVER: %s: fifo thread rebose on put\n", __func__);
    ret = 0;
  }

  s = pthread_mutex_unlock(&pthread_mutex);
  if (s != 0){
    printf("***SERVER ERROR***: %s: phtread_mutex_unlock error :%i\n", __func__, s);
    return -1;
  }
  return ret;
}

/* This function is called whenever it closes server.
 * It cleans de index of event queue or fifo.
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
static int fifo_flush(fifo_t *q) {
  int s = 0;
  s = pthread_mutex_lock(&pthread_mutex);
  if (s != 0)
	printf("***SERVER ERROR***: %s: phtread_mutex_lock\n",__func__);

  q->rd_idx = q->wr_idx = 0;
  q->cnt = 0;

  s = pthread_mutex_unlock(&pthread_mutex);
  if (s != 0)
    printf("***SERVER ERROR***: %s: phtread_mutex_unlock\n",__func__);
  return 0;
}

/* This function obtains the checksum to be send it.
 * @param socket - message.
 * @return - checksum value
 */
static int checksum_opt(uint32_t *buff, int size){
  uint32_t chks_sum = 0;
  int i = 0;
  for (i = 0; i < size-1 ;i++){// only Header + Payload
    //printf("chks_sum = %08X, buff_ptr[i] = %08X \n", chks_sum, buff[i]);
    chks_sum = chks_sum + buff[i];
  }
  return chks_sum;
}

/* This function tests the checksum.
 * @param socket - message.
 * @return - 0 if success, other if fail.
 */
static int checksum_test(uint32_t *buff, int size)
{
  uint32_t chks_sum = 0;
  uint32_t chks_value = 0;
  int result = -1;

  //Obtein checksum send it
  chks_value = buff[size-1];
  //Obtein checksum read it
  chks_sum = checksum_opt(buff, size);

  result = chks_sum - chks_value;//0 if it's same

  return result;
}

/*
 * Safe way to modify a global variable.
 * @param *var - Pointer to variable to modify.
 * @param value - value to set.
 * @return - 0 if success, other if fail.
 */
static int safe_set_global( int *var, int value) {

  int s = 0;
  s = pthread_mutex_lock(&pthread_mutex);
  if (s != 0){
    printf("***SERVER ERROR***: %s: phtread_mutex_lock\n",__func__);
    return -1;
  }

  //sem_wait(&sem_global);
  *var = value;
  dbg_printf("SERVER : %s: *var = %d\n",__func__,*var);
  //sem_post(&sem_global);

  s = pthread_mutex_unlock(&pthread_mutex);
  if (s != 0){
    printf("***SERVER ERROR***: %s: phtread_mutex_unlock\n",__func__);
    return -1;
  }
  return 0;
}

/*
 * Safe way to get a global variable.
 * @param *var - Pointer to variable to get.
 * @param *value - Pointer to variable to save result.
 * @return - 0 if success, other if fail.
 */
static int safe_get_global( int *var, int *value) {

  int s = 0;
  s = pthread_mutex_lock(&pthread_mutex);
  if (s != 0){
    printf("***SERVER ERROR***: %s: phtread_mutex_lock\n",__func__);
    return -1;
  }

  if(*value == *var){
    *value = *var;
  }else{
    *value = *var;
    dbg_printf("SERVER : %s: *value= %d\n",__func__,*value);
  }

  s = pthread_mutex_unlock(&pthread_mutex);
  if (s != 0){
    printf("***SERVER ERROR***: %s: phtread_mutex_unlock\n",__func__);
    return -1;
  }
  return 0;
}

/* Recv with timeout.
 * @param socket - Socket TCP.
 * @param *buffer - Pointer to buffer data.
 * @param length - length of transaction.
 * @param timeout - Timeout in seconds
 * @return - 0 if success, other if fail.
 */
static int recvtimeout(int socket, fifo_data_t *buffer, int length, int timeout)
{
    fd_set fds;
    int n;
    struct timeval timeval_str;
    // Build the set of file descriptors
    FD_ZERO(&fds);
    FD_SET(socket, &fds);
    // Build the timeval structure of the timer
    timeval_str.tv_sec = timeout;
    timeval_str.tv_usec = 0;
    // Wait until data is received or the timer expires
    n = select(socket+1, &fds, NULL, NULL, &timeval_str);
    if (n == 0) return -2; // The timer has expired! or the connection is closed
    if (n == -1) return -1; // Error
    // The data must be there, so I usually call recv()
    return readn(socket, buffer, length);
}

/* Safe function to send all data.
 * @param socket - Socket TCP.
 * @param *buffer - Pointer to buffer data.
 * @param *length - Pointer to length transaction.
 * @param flags - Flags to send().
 * @return - 0 if success, other if fail.
 */
static int send_all(int socket, fifo_data_t *buffer, int *length, int flags)
{
  int total = 0;        //how many bytes we have been send
  int bytesleft = *length; // how many bytes are pending
  int n;
  while(total < *length)
  {
    n = send(socket, buffer+total, bytesleft, flags);
    //printf("SERVER--->: numero de bytes enviados: %d\n", n);
    if (n == -1) { break; }// and show error
    total += n;
    bytesleft -= n;
  }

  *length = total; // return number of bytes send
  //printf("SERVER: numero de bytes enviados total: %d\n",total);
  return n==-1?-1:0; // return -1 if fail, other case 0
}

/* HelloWorldTest -  Test function to verify net
 * @return - 0 if success, other if fail.
 */
static int HelloWorldTest(void) {
  int ret = -1;
  memset(net_str.rx_buffer, 0, 4);
  net_str.valread = 0;

  do{
    if ((net_str.valread = recvtimeout(net_str.new_socket, net_str.rx_buffer,
                                       4, TIMEOUT)) == -1){
      printf("***SERVER ERROR***: psc-api.c: %s: Fail to read: %s.\n",__func__, strerror(errno));
    }else if (net_str.valread == 0) {
      printf("***SERVER ERROR***: psc-api.c: %s: Value read 0. Connection lost.\n",__func__);
    }else if (net_str.valread == -2){
      printf("***SERVER INFO***: The server timed out waiting for the request.\n");
    }else{
      //ret = 0;
    }
  }while(net_str.valread == -2);// repeat in case of time out warning


  // send hello from server
  net_str.wx_buffer[0] = net_str.rx_buffer[0];
  net_str.valsend = 4;

  //Send message
  if((net_str.valsend = send_all(net_str.new_socket, net_str.wx_buffer,
                                  &(net_str.valsend), FLAG_SEND)) < 0){
    printf("***SERVER ERROR***: psc-api.c: %s: Fail to send: %s.\n",__func__, strerror(errno));
    return net_str.valsend;
  }else{
    ret = 0;
  }

  memset(net_str.wx_buffer, 0, 4);
  memset(net_str.rx_buffer, 0, 4);
  return ret;
}

/* This function is used to obtain data net from host.
 * @return - 0 if success, other if fail.
 */
static int obtain_ip(int fd)
{
  struct ifreq ifr;

  #ifdef SOC
  char iface[] = "eth0";
  #else
  char iface[] = "enp1s0";
  #endif
  //Type of address to retrieve - IPv4 IP address
  ifr.ifr_addr.sa_family = AF_INET;
  //Copy the interface name in the ifreq structure
  strncpy(ifr.ifr_name , iface , IFNAMSIZ-1);
  //Get the ip address
  if (ioctl(fd, SIOCGIFADDR, &ifr)==-1) {
      close(fd);
      perror("***SERVER ERROR***: obtain_ip");
      return -1;
  }
  //Display ip
  printf("SERVER: %s: My IP address of %s is: %s\n" ,__func__, iface , inet_ntoa(( (struct sockaddr_in *)&ifr.ifr_addr )->sin_addr) );
  //Get the netmask ip
  if (ioctl(fd,SIOCGIFNETMASK,&ifr)==-1) {
      close(fd);
      perror("***SERVER ERROR***: obtain_ip");
      return -1;
  }
  //Display netmask
  printf("SERVER: %s: My Netmask of %s is: %s\n" ,__func__, iface , inet_ntoa(( (struct sockaddr_in *)&ifr.ifr_addr )->sin_addr) );
  return 0;
}

/* Thread of LDD
 *
 */
static void *thread_ldd(void *arg)
{
  dbg_printf("SERVER: %s: LDD thread LDD open: %08x.\n", __func__, pthread_self());
  int ret, fd, i;
  uint32_t DataFromLDD[SIZE_PAYLOAD_LONG] = {};
  int sem_read_safe;

  // Init fifo
  fifo_init(&fifo_str);
  // Clean fifo.
  fifo_flush(&fifo_str);

  switch (State_thread)
  {
    case IOCTL_TO_LDD_THREAD:  // WRITE TO LDD
      #ifdef SOC
      ret = ioctl(fd_ldd, net_str.cmd_full, &net_str.value_reg);
      if (ret < 0){
        printf("fd = %d\n",fd);
        perror("***SERVER ERROR***: Failed to use ioctl with LDD.");
        safe_set_global(&errorc, ERR_IOCTL_LDD);
        return &errno;
      }
      #else
      net_str.value_reg = 0xABCDEF12;
      #endif
      fifo_put_int(&fifo_str, net_str.value_reg, 1);// Only a 32 bits word
      dbg_printf("SERVER: %s: IOCTL OK.\n", __func__);
      break;

    case READ_FROM_LDD_THREAD: // READ FROM LDD
      #ifdef SOC
      //1º Run acquisition
      ret = ioctl(fd_ldd, net_str.cmd_full, &net_str.value_reg);
      if (ret < 0){
        printf("fd = %d\n",fd);
        perror("***SERVER ERROR***: Failed to use ioctl with LDD.");
        safe_set_global(&errorc, ERR_IOCTL_LDD);
        return &errno;
      }
      #else

      #endif
      //2º Read acquisition
      while (run_thread){//if streaming... no close thread
        //safe_get_global( &sem_read, &sem_read_safe);
        sem_wait(&sem_global);
        if (run_thread == 0) break;

        //if (sem_read){// Only when client is ready
          // Read the response from the LKM. Only the Payload.
          printf("SERVER: %s: Leyendo del LDD.\n", __func__);

/*printf("###Antes de read(), ANTES de leer del LDD\n");
      mil_anterior = current_timestamp(mil_anterior);*/

          ret = read(fd_ldd, DataFromLDD, SIZE_PAYLOAD_LONG_B);
          if (ret < 0){
            perror("SERVER: thread_ldd: Failed to read the message from the LDD");
            safe_set_global(&errorc, ERR_READ_LDD);
            return &errno;
          }

/*printf("###Despues de read(), DESPUES de leer del LDD\n");
      mil_anterior = current_timestamp(mil_anterior);*/
          printf("SERVER: %s: Datos leidos ret = %d.\n", __func__, ret);

          /*ret3 = write(fd_log2,  DataFromLDD, ret); // Send the string to the LKM
          if (ret3 < 0){
            perror("Failed to write the message to the device.");
          }else if(ret3==0){
            printf("SERVER: %s: No data written ...ret2 = %d.\n", __func__, ret3);
          }
          printf("SERVER: %s: Datos escritos ret = %d.\n", __func__, ret3);*/

          // Put response. Only the Payload.
          ret = fifo_put(&fifo_str, DataFromLDD, SIZE_PAYLOAD_LONG);
          if (ret < 0){
            perror("SERVER: thread_ldd: Failed to put into fifo.");
            safe_set_global(&errorc, ERR_READ_LDD);
          }
          //safe_set_global(&sem_read, 0);

/*printf("###Despues de fuardar datos en Fifo en thread\n");
      mil_anterior = current_timestamp(mil_anterior);*/

        //}else{
           //dbg_printf("SERVER: %s: waiting for OK response.\n", __func__);
            //waiting for OK response
        //}
        //break; //FIXME
      }
      break;
    default:
      break;
  }

}
/* Main to network
 *
 */
int main(int argc, char const *argv[])
{
  net_str.value_reg = 0;
  sem_read = 0;
  
  struct sockaddr_in servaddr;
  int servaddrlen = sizeof(servaddr);
  int server_fd;
  char hostname[100];

  int State_main = 0;
  int streaming_mode = 0;

  uint32_t len_msg = 0;
  uint32_t cheksum = 0;

  int i, ret;
  int yes = 1;
  errorc = 0;

  pthread_t t_ldd_id;
  fifo_data_t fifo_data;
  State_thread = 0;
  
  //TODO:quitar
  mil_anterior =0;
  sem_init(&sem_global,0,0);

  printf("SERVER: %s: I'm SERVER. v%1.1f\n",__func__,VERSION);

  /* Creating socket file descriptor
  int sockfd = socket(domain, type, protocol);
  Domain:		AF_INET         IPv4 Internet protocols.
  Type:		SOCK_STREAM     Provides sequenced, reliable, two-way, connection-
                        based byte streams.  An out-of-band data transmission
                        mechanism may be supported.
  Protocol:	0				This is the same number which appears on protocol field
                in the IP header of a packet.
                (man protocols for more details)
  */
  server_fd = socket(AF_INET, SOCK_STREAM, PROTOCOL_SOCKET);
  if (server_fd < 0)
  {
      perror("***SERVER ERROR*** Socket creation failed.");
      exit(EXIT_FAILURE);
  }

  // Forcefully attaching socket to the port PORT
  /* man 2 setsockopt for felp.
  setsockopt helps in manipulating options for the socket referred
  by the file descriptor sockfd. This is completely optional, but it
  helps in reuse of address and port. Prevents error such
  as: “address already in use”.
  */
  if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                &yes, sizeof(yes)) == -1)
  {
      perror("***SERVER ERROR*** setsockopt failed.\n");
      exit(EXIT_FAILURE);
  }

  servaddr.sin_family = AF_INET;
  servaddr.sin_port = htons(PORT); /* "host-to-net-work-short", daytime server*/
  /* INADDR_ANY is used when you don't need to bind a socket to a specific IP.
  When you use this value as the address when calling bind(), the socket accepts
  connections to all the IPs of the machine.
  */
  servaddr.sin_addr.s_addr = INADDR_ANY;
  /* Other option to specific IP: inet_pton - convert IPv4 and IPv6 addresses
  from text to binary form.
  */
  /*if (inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0)
  {
    perror("Server ERROR: inet_pton().");
        exit(EXIT_FAILURE);
  }*/

  // Forcefully attaching socket to the port PORT
  if (bind(server_fd, (struct sockaddr *)&servaddr,
                               sizeof(servaddr)) < 0)
  {
      perror("***SERVER ERROR*** bind failed");
      exit(EXIT_FAILURE);
  }

  // Listen server
  if (listen(server_fd, LISTENQ) < 0)
  {
      perror("***SERVER ERROR*** listen failed");
      exit(EXIT_FAILURE);
  }

  // Obtain Server info
  if(gethostname(hostname,sizeof(hostname)) < 0)
  {
      perror("***SERVER ERROR*** Get host name failed");
      exit(EXIT_FAILURE);
  }
  printf("SERVER: My host name is: %s.\n", hostname);

  // Obtain IP of server
  if(obtain_ip(server_fd) < 0){
      printf("***SERVER ERROR***: %s: Obtain IP failed.\n",__func__);
      exit(EXIT_FAILURE);
  }
  printf("SERVER: My Port is: %i.\n", PORT);

  //Prepare main loop
  State_main = WAITING_STATE_MAIN; //START WITH WAITING STATE
  // Ready to start
  while (TRUE)
  {
    switch (State_main)
    {
    case WAITING_STATE_MAIN:  // WAITING STATE
      // INPUT STATE
      // ...
      // IMPLEMENTAION STATE
      // Wait for client connect.

      printf("SERVER: Waiting for client...\n\n");
      if ((net_str.new_socket = accept(server_fd, (struct sockaddr *)&servaddr,
          (socklen_t*)&servaddrlen)) < 0)
      {
        perror("***SERVER ERROR*** accept failed");
        break;
      }

      // Open LDD
      fd_ldd = open(LDD_PATH, O_RDWR);// Open the device with read/write access
      if (fd_ldd < 0){
        perror("***SERVER ERROR***: Failed to open the LDD");
        break;
      }
      dbg_printf("SERVER: %s: LDD opened - OK.\n", __func__);

      // Test net with a simple message
      if(HelloWorldTest() < 0){
        printf("***SERVER ERROR***: %s: Hello World Test not success.\n", __func__);
        break;
      }
      printf("SERVER: Client connected.\n");

      //OPUTPUT STATE
      State_main = READ_STATE_MAIN; // To Connection State
      break;
    case READ_STATE_MAIN: // CONNECTION STATE
      // INPUT STATE
      // ...
      // IMPLEMENTAION STATE
      // Read request
      memset(net_str.rx_buffer, 0, SIZE_BUFFER_SHORT_B);
      net_str.valread = 0;

      do{
        net_str.valread = recvtimeout(net_str.new_socket, net_str.rx_buffer,
                                           SIZE_BUFFER_SHORT_B, TIMEOUT);
        if (net_str.valread == -2){
          printf("***SERVER INFO***: The server timed out waiting for the request.\n");
        }
      }while(net_str.valread == -2);// repeat in case of time out warning
 
      if (net_str.valread == 0){
        printf("***SERVER ERROR***: psc-api.c: %s: Value read 0. Connection lost.\n",__func__);
        State_main = WAITING_STATE_MAIN;
        break;
      }else if(net_str.valread == -1){
        printf("***SERVER ERROR***: psc-api.c: %s: Fail to read: %s.\n",__func__,
               strerror(errno));
        State_main = WAITING_STATE_MAIN;
        break;      
      }

/*printf("###Despues de recibir datos, antes de obtenerlos\n");
      mil_anterior = current_timestamp(mil_anterior);*/

      // LENGHT
      len_msg = net_str.rx_buffer[0];

      // COMMAND
      net_str.magic_num = GET_MAGIC_NUM(net_str.rx_buffer[1]);
      net_str.cmd_us = GET_CMD_US(net_str.rx_buffer[1]);
      net_str.cmd_ldd = GET_CMD_LDD(net_str.rx_buffer[1]);
      net_str.param = GET_PARAM(net_str.rx_buffer[1]);
      net_str.cmd_full = GET_CMD_FULL(net_str.magic_num, net_str.cmd_us, net_str.cmd_ldd,
                                      net_str.param);
      // DATA
      net_str.value_reg = net_str.rx_buffer[2];
      // CHECKSUM
      cheksum = net_str.rx_buffer[3];
      // Test check sum
      ret = checksum_test(net_str.rx_buffer, SIZE_BUFFER_SHORT);

      if(ret < 0){
        printf("***SERVER ERROR***: psc-api.c: %s: error in checksum_test()\n");
        safe_set_global(&errorc, ERR_CHK);
        State_main = ERROR_STATE_MAIN;// To Error State
        break;// Don't take account this cycle
      }else{
        dbg_printf("\nCHECKSUM OK\n");
      }

      dbg_printf("server.c: %s: net_str.rx_buffer[1] = %08X, magic_num = %02X, cmd_us = %02X, "
      "cmd_ldd = %02X, param = %02X, data = %08X\n", __func__, net_str.rx_buffer[1],\
      net_str.magic_num, net_str.cmd_us, net_str.cmd_ldd, net_str.param,\
      net_str.value_reg);

      if(streaming_mode){
        switch(net_str.cmd_us) {
        case CMD_US_OK:
          dbg_printf("server.c: %s: CMD_US_OK.\n",__func__);

/*printf("###Despues de recibir datos, antes de obtenerlos\n");
      mil_anterior = current_timestamp(mil_anterior);*/

          //safe_set_global(&sem_read, 1);
          sem_post(&sem_global);
          State_main = SEND_STATE_MAIN;// To Streaming State
          break;

        case CMD_US_STOP:// stop
          streaming_mode = 0;
          dbg_printf("server.c: %s: CMD_US_STOP.\n",__func__);

          // deshabilitar lectura
          State_main = READ_STATE_MAIN;// To Streaming State
          safe_set_global(&State_thread, 0);

          //Close LDD thread.
          safe_set_global(&run_thread, 0);
          sem_post(&sem_global);
          if (pthread_join(t_ldd_id, NULL) < 0){
            perror("***SERVER ERROR*** pthread_join: thread LDD didn't close.");
            safe_set_global(&errorc, ERR_CLOSE_TRHEAD_LDD);
            State_main = ERROR_STATE_MAIN;// To Error State
            break;
          }
          dbg_printf("Thread LDD closed: %08x.\n\r", thread_ldd);

          /*ret2 = close(fd_log); // close
          if (ret2 < 0){
            perror("SERVER:Failed to close the message to the device.");
            return -1;
          }*/

          break;

        case CMD_US_EXIT:
          dbg_printf("server.c: %s: CMD_US_EXIT.\n",__func__);
          ret = close(fd_ldd);// Open the device with read/write access
          if (ret < 0){
            perror("***SERVER ERROR***: Failed to close the LDD");
            safe_set_global(&errorc, ERR_CLOSE_LDD);
            State_main = ERROR_STATE_MAIN;// To Error State
            break;
          }
          exit(0);
          break;

        /*case CMD_US_FOO:

          break;*/

        default:
          printf("***SERVER INFO***: Not  server command correct. "
		 "Options abiable: CMD_US_OK, CMD_US_STOP, CMD_US_EXIT.\n");
          break;
        }
      }
      else {// if not stream mode
        switch(net_str.cmd_us) {
        case CMD_US_SET:
          dbg_printf("SERVER: CMD_US_SET selected.\n");
          // Run ioctl command
          safe_set_global(&State_thread, IOCTL_TO_LDD_THREAD);

          // Create LDD thread
          if (pthread_create(&t_ldd_id, NULL, thread_ldd, NULL) < 0)
          {
            perror("***SERVER ERROR***: %s: Error at create LDD thread");
            safe_set_global(&errorc, ERR_OPEN_TRHEAD_LDD);
            State_main = ERROR_STATE_MAIN;// To Error State           
            break;
          }
          State_main = SEND_STATE_MAIN;// To Streaming State
          // Wait to finish LDD thread
          if (pthread_join(t_ldd_id, NULL) < 0){
            perror("***SERVER ERROR*** %s: Error at close LDD thread");
            safe_set_global(&errorc, ERR_CLOSE_TRHEAD_LDD);
            State_main = ERROR_STATE_MAIN;// To Error State
            break;
          }
          dbg_printf("Thread LDD closed: %08x.\n\r", thread_ldd);
          break;

        case CMD_US_GET:
          dbg_printf("SERVER: CMD_US_GET selected.\n");
          // Run IOCTL
          safe_set_global(&State_thread, IOCTL_TO_LDD_THREAD);

          // Create LDD thread
          dbg_printf("SERVER: Thread LDD created.\n");
          if (pthread_create(&t_ldd_id, NULL, thread_ldd, NULL) < 0)
          {
            perror("***SERVER ERROR*** pthread_create: thread LDD");
            safe_set_global(&errorc, ERR_OPEN_TRHEAD_LDD);
            State_main = ERROR_STATE_MAIN;// To Error State                   
            break;
          }
          State_main = SEND_STATE_MAIN;// To Streaming State
          // Wait fot thread
          if (pthread_join(t_ldd_id, NULL) < 0){
            perror("\n***SERVER ERROR*** pthread_join: Error at close LDD thread");
            safe_set_global(&errorc, ERR_CLOSE_TRHEAD_LDD);
            State_main = ERROR_STATE_MAIN;// To Error State
            break;
          }
          dbg_printf("Thread LDD closed: %08x.\n\r", thread_ldd);
          break;

        case CMD_US_RUN:
          dbg_printf("SERVER: CMD_US_RUN selected.\n");

          streaming_mode = 1;
          // Activate reading
          //safe_set_global(&sem_read, 1);
          sem_post(&sem_global);
          safe_set_global(&State_thread, READ_FROM_LDD_THREAD);

          // Create LDD thread
          dbg_printf("SERVER: Thread LDD created.\n");
          safe_set_global(&run_thread, 1);
          if (pthread_create(&t_ldd_id, NULL, thread_ldd, NULL) < 0)
          {
            perror("***SERVER ERROR*** pthread_create: thread LDD");
            safe_set_global(&errorc, ERR_OPEN_TRHEAD_LDD);
            State_main = ERROR_STATE_MAIN;// To Error State       
            break;
          }
          State_main = SEND_STATE_MAIN;// To Streaming State

          dbg_printf("Starting device test code example...\n");
	  // Open the device
          /*fd_log = open("/home/root/server_data.bin", S_IRWXU|O_RDWR|O_CREAT);
          if (fd_log < 0){
            perror("SERVER: Failed to open the device fd_log...");
            return -1;
          }*/
	  // Open the device
          /*fd_log2 = open("/home/root/server_data2.bin", S_IRWXU|O_RDWR|O_CREAT);
          if (fd_log2 < 0){
            perror("SERVER: Failed to open the device fd_log2...");
            return -1;
          }*/

          break;

        case CMD_US_EXIT:
          dbg_printf("SERVER: CMD_US_EXIT selected.\n");
          ret = close(fd_ldd);// Open the device with read/write access
          if (ret < 0){
            perror("***SERVER ERROR***: Failed to close the LDD");
            safe_set_global(&errorc, ERR_CLOSE_LDD);
            State_main = ERROR_STATE_MAIN;// To Error State
            break;
          }
          exit(0);
          break;

        /*case CMD_US_FOO:

          break;*/

        default:
          printf("***SERVER INFO***: Not  server command correct. "
		 "Options abiable: CMD_US_SET, CMD_US_GET, CMD_US_RUN, CMD_US_EXIT.\n");
          break;
        }
      }

      break;

    case SEND_STATE_MAIN:
    
      if(errorc == 0){// if not error
        if(!fifo_empty(&fifo_str)){ // There is data into fifo.
          dbg_printf("SERVER: %s: count = %i\n",__func__, fifo_count(&fifo_str));

/*printf("###Antes de enviar datos, depsues de fifo llena\n");
      mil_anterior = current_timestamp(mil_anterior);*/

          int i;

          net_str.cmd_full &= 0x00FFFFFF;
          net_str.cmd_full |= (MAGIC_NUM_SERVER << 24);

          net_str.wx_buffer[1] = net_str.cmd_full | ACK_CMD_PROCESSED;
          // Built message
          if (streaming_mode){// LONG_MSG

            net_str.wx_buffer[0] = SIZE_BUFFER_LONG_B;
            for(i = SIZE_HEADER; i < (SIZE_BUFFER_LONG - SIZE_CHECKSUM); i++) {
              ret = fifo_get(&fifo_str, &fifo_data);
              if (ret){
               // printf("SERVER: %s: Value read= %i\n",__func__, fifo_data);
              }
              net_str.wx_buffer[i]=fifo_data;
            }
            net_str.wx_buffer[SIZE_BUFFER_LONG-1] = checksum_opt(net_str.wx_buffer, SIZE_BUFFER_LONG);
            net_str.valsend = SIZE_BUFFER_LONG_B;// see common.h

            //Write data in a file log.
            /*ret2 = write(fd_log,  net_str.wx_buffer, SIZE_BUFFER_LONG_B); // Send the string to the LKM
            if (ret2 < 0){
              perror("Failed to write the message to the device.");
              goto error1;
            }else if(ret2==0){
              printf("SERVER: %s: No data written ...ret2 = %d.\n", __func__, ret2);
            }*/
          } else {// SHORT_MSG
            ret = fifo_get(&fifo_str, &fifo_data);// Read only a word of 32 bits
            net_str.value_reg = fifo_data;
            // Send response
            net_str.wx_buffer[0] = SIZE_BUFFER_SHORT_B;
            net_str.wx_buffer[2] = net_str.value_reg;
            net_str.wx_buffer[3] = checksum_opt(net_str.wx_buffer, SIZE_BUFFER_SHORT);
            net_str.valsend = SIZE_BUFFER_SHORT_B;// see common.h
            net_str.value_reg = 0;
          }

          // Send answer/data
          if(send_all(net_str.new_socket, net_str.wx_buffer, &net_str.valsend,
              FLAG_SEND) == -1){
            printf("***SERVER ERROR***: %s: send data fail: %s.\n",__func__, strerror(errno));
            if (net_str.valsend != sizeof(net_str.wx_buffer))
            {
              printf("SERVER: %s: We only sent %d bytes because of the error!\n",__func__, net_str.valsend);
            }
            break;
          }

          //Reset
          net_str.valsend=0;
          net_str.cmd_full = 0;
          memset(net_str.wx_buffer,0, SIZE_BUFFER_LONG_B);



/*printf("###Despues de enviar datos\n");
      mil_anterior = current_timestamp(mil_anterior);*/


          State_main = READ_STATE_MAIN;// para recibir respuesta de OK o comando
        }
      }else{
        State_main = ERROR_STATE_MAIN;// To Error State
      }
      break;

    case ERROR_STATE_MAIN:    
      net_str.wx_buffer[0] = SIZE_BUFFER_SHORT_B;
      net_str.wx_buffer[1] = net_str.cmd_full | ERROR_EVENT;
      net_str.wx_buffer[2] = errorc;
      net_str.wx_buffer[3] = checksum_opt(net_str.wx_buffer, SIZE_BUFFER_SHORT);
      
      if(send_all(net_str.new_socket, net_str.wx_buffer, &net_str.valsend,
            FLAG_SEND) == -1){
        printf("***SERVER ERROR***: %s: send data fail: %s.\n",__func__, strerror(errno));
        if (net_str.valsend != sizeof(net_str.wx_buffer))
        {
          printf("SERVER: %s: We only sent %d bytes because of the error!\n",__func__, net_str.valsend);
        }
        break;
      }
      errorc = 0;
      State_main = READ_STATE_MAIN;
    break;
    default:
      break;
    }
  }
  return 0;
  /*error1:
    ret2 = close(fd_log); // close
    if (ret2 < 0){
      perror("Failed to close the message to the device.");
      return -1;
    }
    //close (fd_log2);
    return -1;*/
}

