/*  io_user_space_ldd.h - I/O functon to talk with User Space
******************
* Edel Diaz Llerena
* 01/06/2018
* University of Alcala
******************
* Description:
* In this file is open(), read(), write(), ioctl() and close() 
* functions that run as callbacks from User Space.
******************
* Change log:
******************
*/

#ifndef PSC_LDD_H
#define PSC_LDD_H

/*Includes*/
#include <linux/kernel.h>       // Contains types, macros, functions for the kernel
#include <linux/init.h>         // Macros used to mark up functions e.g. __init __exit
#include <linux/module.h>       // Core header for loading LKMs into the kernel
#include <linux/io.h>
#include <linux/interrupt.h>    // Required for the IRQ code
#include <linux/string.h>       // Required for the memset funciton

#include <linux/of_address.h>
#include <linux/of_device.h>
#include <linux/of_platform.h>

#include "common.h"     //CMD, ADDRESS, OFFSET, REGISTERS and others
#include "fifo_ldd.h"




/*Structs*/
struct mymodule_local {
  int irq;
  int irq_allocated;
  unsigned long mem_start;
  unsigned long mem_end;
  void __iomem *base_addr;
};

/*Variables*/
static struct cdev c_dev; // Global variable for the character device structure
static int    majorNumber;  //Stores the device number -- determined automatically
static struct class*  mymoduleClass  = NULL;  // The device-driver class struct pointer
static struct device* mymoduleDevice = NULL;  // The device-driver device struct pointer

typedef struct irq_str {
	int irq_ready;
	spinlock_t    queue_lock;
}irq_t;
irq_t irq_str;
int irq_ready;

//static uint32_t i = 0;

#endif


