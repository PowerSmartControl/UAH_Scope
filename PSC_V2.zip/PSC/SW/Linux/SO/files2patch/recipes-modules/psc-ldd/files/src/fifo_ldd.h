/*  fifo.h - Fifo to set data from irq callback to driver_read().
******************
* Edel Diaz Llerena
* 01/06/2018
* University of Alcala
******************
* Description:

******************
* Change log:
******************
*/
#ifndef FIFO_LDD_H
#define FIFO_LDD_H

/* INCLUDES */
#include <linux/kernel.h>       // Contains types, macros, functions for the kernel
#include <linux/spinlock.h>
#include <linux/wait.h>
#include <linux/sched.h>//todo quitar

#include "common.h"     //CMD, ADDRESS, OFFSET, REGISTERS and others

/* DEFINES */
#define BRAM_ADDR_MIN      BRAM_INDEX // 2048 values = 8KB with 32bits
#define BRAM_ADDR_MAX      4096 // 2048 values = 8KB with 32bits
#define FIFO_SIZE ((BRAM_ADDR_MAX-BRAM_ADDR_MIN)*2)

/* TYPES, VARIABLES AND STRUCTS */
typedef uint32_t fifo_data_t;
/* FIFO struct
 */
typedef struct fifo {
	uint32_t      rd_idx;               // reading index
	uint32_t      wr_idx;               // writing index
	uint32_t      cnt;                  // number of elements
	fifo_data_t      data[FIFO_SIZE];   // buffer/fifo
	wait_queue_head_t wait_on_rd;       // queue head
	spinlock_t    queue_lock;           // spinlock
}fifo_t;

/* FUNCTIONS */
/******************* FIFO Help functions ******************/

/* This function is called when init this driver, i.e. __init function. Set fifo
 * and SpinLock.
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
int fifo_init(fifo_t *q);

/* This function is called whenever it read this driver from user space.
 * It is used for test if threa are data into fifo. 
 * @param *q - A pointer to fifo struct.
 * @return - It returns 1 if fifo is empty
 */
int fifo_empty(fifo_t *q);

/* This function is called whenever it read this driver from user space. 
 * @param *q - A pointer to fifo struct.
 * @return - It returns number of events into fifo.
 */
int fifo_count(fifo_t *q);

/* This function is called whenever it read this driver from user space. 
 * Fifo data is send to driver_read() function.
 * @param *q - A pointer to fifo struct.
 * @param *data - A pointer to buffer to read from user space. Typically uint32_t.
 * @return - It returns 0 if successful.
 */
int fifo_get(fifo_t *q, fifo_data_t *data);

/* This function is called whenever an irq occurs. It copies BRAM data from 0 to
 * BRAM_DATA_SIZE into queue. It also increases wr_idx and cnt indexes
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
int fifo_put(fifo_t *q, fifo_data_t *base_address);

/* This function is called whenever it opens this driver from user space. 
 * It cleans de index of event queue or fifo.
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
int fifo_flush(fifo_t *q);
#endif
