/*  common.h - The header common to User-space and LDD
******************
* Edel Diaz Llerena
* 01/06/2018
* University of Alcala
******************
* Description:
* This file has prococol definition and commands, address and other info need it in
* Server(SoC), Client (Windows), and LDD(SoC)
******************
* Change log:
******************
*/
#ifndef COMMON_LDD_H
#define COMMON_LDD_H

/*Defines*/
#define DRIVER_NAME "psc-ldd"
#define DEVICE_NAME "psc-lddDevice"  // The device will appear at /dev/psc-ldd using this value
#define CLASS_NAME "psc-lddClass"  // The device class -- this is a character device driver

//#define DEBUG_FIFO    // Disable to not show printks
//#define DEBUG_LDD     // Disable to not show printks
//#define DEBUG_IO      // Disable to not show printks

#endif


