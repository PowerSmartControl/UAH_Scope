/*  hw_reg.h - Settings of hardware.
******************
* Edel Diaz Llerena
* 01/06/2018
* University of Alcala
******************
* Description:
* This file set the Hw to register into linux device driver.
******************
* Change log:
******************
*/
#ifndef HW_REG_H
#define HW_REG_H

/* Global pointer to relate kernel space with physical address */
static uint32_t *axi_scope_ptr; 
//static uint32_t *myip_dummy_ptr;

/* Definition of IPs to will register. */
/* IMPORTANT */
#ifdef CONFIG_OF
static struct of_device_id mymodule_of_match[] = {
  { .compatible = "uah,axi-scope-1.0", },
  //{ .compatible = "vendor,other-ip-to-register", },
  { /* end of list */ },
};
/*file: plnx_arm-system.dts
axi_scope@40000000 {
  compatible = "xlnx,axi-scope-1.0";
  interrupt-parent = <0x4>; 
  interrupts = <0x0 0x1d 0x4>;
  reg = <0x40000000 0x00200000>; 
  xlnx,din-width = <0x70>;
  xlnx,trigger-width = <0x10>;
};
* VERY IMPORTANT!!!!!: 
* This is 2MB-GP0 for IPs that don't have interrupt with micro.
*/
MODULE_DEVICE_TABLE(of, mymodule_of_match);
#else
# define mymodule_of_match
#endif

static int allocate_mmap(unsigned int mem_start, void * base_addr){

  int ret = 0;
  switch(mem_start){
    case AXI_SCOPE_ADDR:// Here its an  16KB memory (8KB reg + 8KB BRAM)
      //ioremap(lp->mem_start, lp->mem_end - lp->mem_start + 1);
      axi_scope_ptr = (uint32_t *) base_addr;
      /* Clean Axi Scope registers*/
      ret = clean_hw_reg(axi_scope_ptr);
      if(ret < 0){
        printk("###LDD ERROR###: %s.c: %s: Could not "\
               "clean registers\n",DRIVER_NAME,__FUNCTION__);
        return -1;
      }
      break;
    /*case OTHER_IP_ADDR:
      myip_dummy_ptr = (uint32_t *) base_addr;
      break;*/
    default:
      printk("###LDD WARNING###: %s.c: %s: no device found.\n",\
             DRIVER_NAME,__FUNCTION__);
      return -1;
  }
  return 0;
}


#endif
