/*  io_user_space_ldd.h - I/O functon to talk with User Space
******************
* Edel Diaz Llerena
* 01/06/2018
* University of Alcala
******************
* Description:
* In this file is open(), read(), write(), ioctl() and close() 
* functions that run as callbacks from User Space.
******************
* Change log:
******************
*/
#ifndef IO_USER_SPACE_LDD_H
#define IO_USER_SPACE_LDD_H


#include <linux/spinlock.h>
#include <linux/wait.h>
#include <linux/sched.h>
#include <linux/slab.h>         // Required for kmalloc and kfree
#include <linux/fs.h>           // Header for the Linux file system support
#include <linux/uaccess.h>      // Required for the copy_to_user function
#include <linux/cdev.h>         // Required for the cdev functions

#include "fifo_ldd.h"
#include "common.h"

/******************* Register HW Help functions ******************/
int default_hw_reg(uint32_t *base_address);
int clean_hw_reg(uint32_t *base_address);

//TODO
int set_hw_reg(uint32_t *base_address, 
                      uint32_t reg_index,
                      uint32_t reg_shift,
                      unsigned int *arg, unsigned int param);
//TODO
int get_hw_reg(uint32_t *base_address,
                      uint32_t reg_index,
                      uint32_t reg_mask,
                      uint32_t reg_shift,
                      unsigned int *arg);


/******************* I/O functions ******************/
/* The device open function that is called each time the device is opened.
 * This will only open and flush the evente queue.
 * @param *inodep - A pointer to an inode object (defined in linux/fs.h).
 * @param *filep - A pointer to a file object (defined in linux/fs.h).
 * @return - It returns 0 if successful.
 */
int driver_open(struct inode *inodep, struct file *filep);
 
/* This function is called whenever device is being read from user space i.e. 
 * data is being sent from the device to the user. In this case is uses the 
 * __put_user() function to send the buffer string to the user and captures any
 * errors.
 * @param *filep - A pointer to a file object (defined in linux/fs.h).
 * @param *buffer - The pointer to the buffer to which this function writes the 
 * data.
 * @param len - The length of the buffer in bytes.
 * @param *offset - The offset if required.
 * @return - It returns the size of data read.
 */
ssize_t driver_read(struct file *filep, char __user *buffer, size_t len, loff_t *offset);
 
/* This function is called whenever the device is being written to from user 
 * space i.e. data is sent to the device from the user. 
 * @param *filep - A pointer to a file object.
 * @param *buffer - The buffer to that contains the string to write to the device.
 * @param len - The length of the array of data that is being passed in the 
 * const char buffer.
 * @param *offset - The offset if required.
 * @return - It returns the size of data has wrote.
 */
ssize_t driver_write(struct file *filep, const char __user *buffer, size_t len, loff_t *offset);

/* The ioctl function that is called whenever the device wants  send a CMD from 
 * User Space.
 * @param *filep - A pointer to a file object (defined in linux/fs.h).
 * @param srv - Command type input.
 * @param arg - Argument.
 * @return - It returns 0 if successful.
 */
/* IMPORTANT */
long driver_ioctl(struct file *filep, unsigned int srv, unsigned long arg);

/* The device release function that is called whenever the device is 
 * closed/released by the userspace program.
 * @param *inodep - A pointer to an inode object (defined in linux/fs.h).
 * @param *filep - A pointer to a file object (defined in linux/fs.h).
 * @return - It returns 0 if successful.
 */
int driver_release(struct inode *inodep, struct file *filep);


  // Wake up queue head.
int wake_up_interruptible_io(void);

int clean_irq(uint32_t *base_address);

int read_bram(uint32_t *base_address);

int set_axi_scope_ptr(uint32_t *base_address);
int fifo_init_io(void);


#endif
