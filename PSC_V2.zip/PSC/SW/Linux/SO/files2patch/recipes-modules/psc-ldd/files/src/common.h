/*  common.h - The header common to User-space and LDD
******************
* Edel Diaz Llerena
* 01/06/2018
* University of Alcala
******************
* Description:
* This file has prococol definition and commands, address and other info need it in
* Server(SoC), Client (Windows), and LDD(SoC)
******************
* Change log:
******************
*/
#ifndef COMMON_H
#define COMMON_H

/**************** Protocol and Sockets ****************/
/* The protocol is composed as 32-bit words. There are two messages Little Endian.
* The HEADER has two words:
* The first word is he size in bytes of msg.
* It can be 2+1+1 for Short MSG or 2+2048+1 for Long MSG.
* The second word for FMS control purposes. It has four parameters:
* 1. MAGIC_NUM - It is an ID number to identify the initiator.
* 2. CMD_US - It is a command to FSM control of server(SoC).
* 3. CMD_LDD - It is a command to FSM control of LDD(SoC).
* 4. PARAM - This option is used to select the type of write in HW registers.
*            Also It can be ACK_CMD_PROCESSED to say that the action is successful.
* The PAYLOAD is the data that we want to write or read. Can be 1 word or 2048(8KB) words.
* The CHECKSUM sizes 1 word and tests if the transfer is correct or not.
*                      HEADER                      +       PAYLOAD        +   CHECKSUM
* ------------------------------------------------   --------------------   --------------
* [Size of msg] + [MAGIC_NUM,CMD_US,CMD_LDD,PARAM] + [Data to write/read] + [Checksum]
*
*/
// ID numbers
#define MAGIC_NUM_CLIENT       0xAB
#define MAGIC_NUM_SERVER       0xCD
// Header
#define SIZE_LENGTH            1
#define SIZE_COMMAND_MSG       1
#define SIZE_HEADER            (SIZE_LENGTH + SIZE_COMMAND_MSG)
// PayLoad
#define SIZE_PAYLOAD_SHORT     1
#define SIZE_PAYLOAD_LONG      2048
#define SIZE_PAYLOAD_LONG_B    (SIZE_PAYLOAD_LONG*4)
// Checksum
#define SIZE_CHECKSUM          1
// Size messages
#define SIZE_BUFFER_SHORT      (SIZE_HEADER + SIZE_PAYLOAD_SHORT + SIZE_CHECKSUM)
#define SIZE_BUFFER_SHORT_B    (SIZE_BUFFER_SHORT*4)
#define SIZE_BUFFER_LONG       (SIZE_HEADER + SIZE_PAYLOAD_LONG + SIZE_CHECKSUM)
#define SIZE_BUFFER_LONG_B     (SIZE_BUFFER_LONG*4)
// Param CMDs
#define NORMAL                  0             // General Option: base_address[reg_index] = write_data;
#define OR_OPT                  1             // Set to 1: base_address[reg_index] |= (write_data << reg_shift);
#define AND_NOT_OPT             2             // Set to 0: base_address[reg_index] &= ~(write_data << reg_shift);
#define ACK_CMD_PROCESSED       0x000000FF    // Acknow ledgement command processed
// Socket Settings
#define PROTOCOL_SOCKET	        IPPROTO_TCP             // General protocol for TCP sockets
#define FLAG_SEND               0             // No flags are specified
#define FLAG_READ               MSG_WAITALL	  // MSG_WAITALL
#define TIMEOUT				    10            // in seconds
// Others 
#define ON                      0x01
#define ONE                     0x01
#define OFF                     0x00
#define NONE                    0x00

/**************** Commands decode ****************/
#define GET_MAGIC_NUM(srv)     (((srv) >> 24) & 0xFF)
#define GET_CMD_US(srv)        (((srv) >> 16) & 0xFF)
#define GET_CMD_LDD(srv)       (((srv) >> 8) & 0xFF)
#define GET_PARAM(srv)         ((srv) & 0xFF)
#define GET_CMD_FULL(magic_num, cmd_us, cmd_ldd, param)\
                                ((magic_num) << 24) | ((cmd_us) << 16) | ((cmd_ldd) << 8) | param 
#define SET_MAGIC_NUM(srv)     ((srv) << 24)
#define SET_CMD_US(srv)        ((srv) << 16)
#define SET_CMD_LDD(srv)       ((srv) << 8)
#define SET_PARAM(srv)         (srv) 
#define SET_CMD_FULL(magic_num, cmd_us, cmd_ldd, param)\
                                magic_num | cmd_us | cmd_ldd | param 

/**************** User-Space Commands ****************/
// FSM User-Space App 
#define WAITING_STATE_MAIN      0x01    // Waiting for connect state
#define READ_STATE_MAIN         0x02    // Read data from client(Windows)
#define SEND_STATE_MAIN         0x03    // Send data to client(Windows)
#define EXIT_STATE_MAIN         0x04    // Exit state, close thread.
// Actions Thread LDD 
#define IOCTL_TO_LDD_THREAD     0x05    // Send ioctl CMD input to LDD and send 
// Read from LDD/HW
#define READ_FROM_LDD_THREAD    0x06    // Read from LDD data into BRAM(HW)
// Prococol CMD from client to User-Space application (FSM-server-SoC)
#define CMD_US_SET              0x00    // Set a value into a register (HW)
#define CMD_US_GET              0x01    // Get a value from a register (HW)
#define CMD_US_RUN              0x02    // Start adquisition
#define CMD_US_STOP             0x03    // Stop adquisition	
#define CMD_US_EXIT             0x04    // Exit of the application
#define CMD_US_OK               0x05    // Data recived in client OK
//#define CMD_US_FOO              0xXX    // 0x0F to 0xFF Commands free actually

/**************** Linux Device Driver Commands ****************/
// Prococol CMD from Linux Device Driver  to HW (SoC and HW) 
#define CMD_LDD_CORE_ENABLE     0x00    // Core enable (axi-scope-1.0)
#define CMD_LDD_SW_RESET        0x01    // Sofware reset( axi-scope-1.0)
#define CMD_LDD_SINGLE_MODE     0x02    // Set single mode (axi-scope-1.0)
#define CMD_LDD_TRIGGER_MODE    0x03    // Set trigger mode (axi-scope-1.0)
#define CMD_LDD_TRIGGER_LEVEL   0x04    // Set trigger level (axi-scope-1.0)
#define CMD_LDD_INT_ENABLE      0x05    // Enable interrupts (axi-scope-1.0)
#define CMD_LDD_INT_ENEBLE_REG  0x06    // Set Interrupt Enable Resiter (axi-scope-1.0)
#define CMD_LDD_INT_FLAG_REG    0x07    // Set Interrupt Flags Register (axi-scope-1.0)
#define CMD_LDD_ACQ_PERIOD      0x08    // Set acquisition period time, this value depends on Zynq frequency (axi-scope-1.0)
#define CMD_LDD_RUN_ACQ         0x09    // RUN/STOP acquisition (axi-scope-1.0)
#define CMD_LDD_DEFAULT_REGS    0x0A    // Set default registers
#define CMD_LDD_CLEAN_REGS      0x0B    // Clean all IP registers 
#define CMD_LDD_BD_REG          0x0C    // Back door to write/read register
//#define CMD_LDD_FOO             0xXX    // 0x0F to 0xFF Commands free actually

/**************** Hardware ****************/
// Address of IPs in HW 
#define AXI_SCOPE_ADDR          0x40000000 //axi-scope-1.0 16KB
#define MYIP_DUMMY_ADDR         0x40010000 //myip_dummy_v1.0 64KB
//#define OTHER_IP_ADDR         0x4XXXXXXX //example_ip_vX.X XXKB
// ATTENTION!!: until 2MB

// BRAM from 2048 to 4095 ->  8KB 
#define BRAM_INDEX              2048

#define MEM_RANGE 0x00100000 //--> del DTB rango maximos asignado para controlar IPS

/**************** AXI_Scope-1.0 Driver ****************/
// This values are defined in Hardware.
// Index of Registers 32 bits  
#define CTRL_REG_INDEX             0
#define VERSION_REG_INDEX          1
#define INT_ENABLE_REG_INDEX       2
#define INT_FLAG_REG_INDEX         3
#define ACQ_PERIOD_REG_INDEX       4
#define TRIG_LEVEL_REG_INDEX       5

// Shifts for CTRL_REG AXI Scope IP 
#define CTRL_REG_CORE_ENABLE_SHIFT  0
#define CTRL_REG_INT_ENABLE_SHIFT   1
#define CTRL_REG_SW_RST_SHIFT       2
#define CTRL_REG_RUN_ACQ_SHIFT      3
#define CTRL_REG_SINGLE_SHIFT       4
#define CTRL_REG_TRIGGER_SHIFT      5
#define NO_SHIFT                    0

// Masks for CTRL_REG AXI Scope IP 
#define CTRL_REG_CORE_ENABLE_MASK  0x00000001
#define CTRL_REG_INT_ENABLE_MASK   0x00000002
#define CTRL_REG_SW_RST_MASK       0x00000004
#define CTRL_REG_RUN_ACQ_MASK      0x00000008
#define CTRL_REG_SINGLE_MASK       0x00000020
#define CTRL_REG_TRIGGER_MASK      0x00000060

// Other masks 
#define ALL_1_MASK                 0xFFFFFFFF
#define ALL_0_MASK                 0x00000000

// Trigger mode
#define CONTINUOUS                 0x00
#define RISING_EDGE                0x01
#define FALLING_EDGE               0x02
#define BOTH_EDGE                  0x03

/**************** Others ****************/
#define TAM 3//BORRAR
#endif


