#!/bin/sh
######
# Edel Díaz Llerena.
# University of Alcala.
######
# PSC Project. 
# 19/10/2018.
######
echo "###file: update_ip.sh v.0.1###"
set -e
# Config ethernet
ethernet_eth='eth0'
ethernet_IP='192.168.75.165'
ethernet_broadcast='192.168.75.255'
ethernet_mask='255.255.255.0'
ethernet_gateway='192.168.75.254'

# Set default IP address
#sleep 5
ifconfig $ethernet_eth down
ifconfig $ethernet_eth $ethernet_IP netmask $ethernet_mask broadcast $ethernet_broadcast up
route add default gw $ethernet_gateway $ethernet_eth
echo -e $ethernet_eth "up with IP" $ethernet_IP 
