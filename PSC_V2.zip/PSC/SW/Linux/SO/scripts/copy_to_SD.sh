#!/bin/bash
clear
set -e
echo "Running file: copy_to_SD.sh"
source /opt/petalinux/petalinux-v2017.4/settings.sh

# 9 - Crear ficheros de arranque para la tarjeta SD.
path_project="/home/edel.diaz/projects/psc-scope/petalinux"
name_prj="psc_linux"
path_to_bit=$path_project/$name_prj/hw/design_1_wrapper.bit
petalinux-package --prebuilt --force --fpga $path_to_bit

# Generar la imagen de arranque en formato .BIN
path_to_elf=$path_project/$name_prj/images/linux/zynq_fsbl.elf
petalinux-package --boot --fsbl $path_to_elf --fpga  --uboot --force -o images/linux/BOOT.BIN

# 10 - Copiar ficheros a SD
cp ./images/linux/image.ub /run/media/edel.diaz/BOOT/image.ub
cp ./images/linux/BOOT.BIN /run/media/edel.diaz/BOOT/BOOT.BIN
echo " "
echo "### FICHEROS COPIADOS A BOOT ###"
echo " "
