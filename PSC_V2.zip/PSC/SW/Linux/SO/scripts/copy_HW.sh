#!/bin/bash
######
# Edel Díaz Llerena.
# University of Alcala.
######
# PSC Project. 
# 19/10/2018.
######
clear
echo "Running file: copy_design.sh"
set -e

path_bitstream=/home/edel.diaz/projects/psc-scope/vivado/linux-test-scope/vivado_2017/linux-test-scope.runs/impl_1/design_1_wrapper.bit
path_hdf=/home/edel.diaz/projects/psc-scope/vivado/linux-test-scope/vivado_2017/linux-test-scope.sdk/design_1_wrapper.hdf
cp $path_bitstream ./design_1_wrapper.bit

cp $path_hdf ./design_1_wrapper.hdf
echo ""
echo ".BIT Y .HDF COPIADOS"
echo ""
