#!/bin/bash
clear
echo "Running file: petalinux-build-all.sh"
set -e

name_prj="psc_linux"

source /opt/petalinux/petalinux-v2017.4/settings.sh
petalinux-config --get-hw-description=/home/edel.diaz/projects/psc-scope/petalinux/$name_prj/hw
petalinux-build -c kernel
petalinux-build -c bootscript
petalinux-build -c rootfs
petalinux-build -c psc-ldd
petalinux-build -x package
petalinux-build 

# Create boot files for the SD card.
path_to_bit=/home/edel.diaz/projects/psc-scope/petalinux/$name_prj/hw/design_1_wrapper.bit
petalinux-package --prebuilt --force --fpga $path_to_bit

# Follow the steps below to generate the boot image in ".BIN" format.
path_to_elf=/home/edel.diaz/projects/psc-scope/petalinux/$name_prj/images/linux/zynq_fsbl.elf
petalinux-package --boot --fsbl $path_to_elf --fpga  --uboot --force -o images/linux/BOOT.BIN

cp ./images/linux/image.ub /run/media/edel.diaz/BOOT/image.ub
cp ./images/linux/BOOT.BIN /run/media/edel.diaz/BOOT/BOOT.BIN
echo " "
echo "### FICHEROS COPIADOS A BOOT ###"
echo " "
