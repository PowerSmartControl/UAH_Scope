#!/bin/bash
clear
echo "Running file: send_module.sh"
set -e

file_module=/home/edel.diaz/projects/psc-scope/petalinux/psc_linux/build/tmp/sysroots/plnx_arm/lib/modules/4.9.0-xilinx-v2017.4/extra/psc-ldd.ko
folder_target=/home/root
folder_host=/home/edel.diaz/projects/psc-scope/petalinux/psc_linux/folder_host
user=root
target=192.168.75.165

#compilar el modulo solo
if [ "$#" -eq 0 ];then
	source /opt/petalinux/petalinux-v2017.4/settings.sh
	petalinux-build -c psc-ldd
fi

cp $file_module $folder_host

#compilar la aplicacion de test
#./testchar-compile.sh

# limpiar las claves SSH
> /home/edel.diaz/.ssh/known_hosts
#enviar carpeta a target
scp -r $file_module $user@$target:$folder_target

#ssh $user@$target 'pwd'

exit

scp -r /lib/modules/4.9.0-xilinx-v2017.4/extra/folder_host/log.bin edel.diaz@192.168.75.128:/home/edel.diaz/log2.bin
scp -r /lib/modules/4.9.0-xilinx-v2017.4/extra/folder_host/server_data.bin edel.diaz@192.168.75.128:/home/edel.diaz/projects/psc-scope/linux-server-client/server-eclipse/server_data.bin

scp -r /home/root/server_data.bin edel.diaz@192.168.75.128:/home/edel.diaz/projects/psc-scope/linux-server-client/server-eclipse/server_data.bin
