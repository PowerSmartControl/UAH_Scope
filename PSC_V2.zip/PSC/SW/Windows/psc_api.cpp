/* psc_api.c - API for Ethernet
 ******************
 * Edel Diaz Llerena
 * 02/10/2018
 * University of Alcala
 ******************
 * Description:
 * This is an API to controller the Hardware of PSC.
 ******************
 * Change log:
 * v2.0 - Updated
 ******************
 * Version:
 * 2.0
 ******************
 */

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include "psc_api.h"

#ifdef _WIN32
#define _CRT_SECURE_NO_WARNINNGS
#endif

/* NOTES:
* - base_address set by client.
* - write_data set by client.
* - reg_index set by Linux Device Driver.
* - reg_shift set by Linux Device Driver.
* OR_OPT, AND_NOT_OPT, NONE defined in common.h.
*/
#define API_ON       OR_OPT // base_address[reg_index] |= (write_data << reg_shift);
#define API_OFF      AND_NOT_OPT // base_address[reg_index] &= ~(write_data << reg_shift);
//#define NONE // base_address[reg_index] = write_data;  in file:common.h
/************** Connection functions **************/
/*
* hola mundo test
*/
static int HelloWorldTest(net_t *net_ptr) {
	int ret = -1;
	net_ptr->hello = 0XABCD0000;
	printf("Message 0x%08X is sending... ", net_ptr->hello);
	net_ptr->valsend = 0;

	if ((net_ptr->valsend = send(net_ptr->new_socket, (char*)&net_ptr->hello,
		4, FLAG_SEND)) < 0)
	{
		printf("send failed with error: %d\n", WSAGetLastError());
		exit(EXIT_FAILURE);
	}

	printf("Waiting for response...\n");
	memset(net_ptr->rx_buffer, 0, SIZE_BUFFER_SHORT_B);
	net_ptr->valread = 0;
	if ((net_ptr->valread = recv(net_ptr->new_socket,
		(char*)net_ptr->rx_buffer, 4, FLAG_READ)) < 0)
	{
		printf("recv failed with error: %d\n", WSAGetLastError());
		exit(EXIT_FAILURE);
	}
	printf("Message read: ");
	printf("0x%02X \n", net_ptr->rx_buffer[0]);
	if (net_ptr->hello == net_ptr->rx_buffer[0]) {
		ret = 0;
	}
	return ret;
}

int connect_zynq(net_t *net_ptr, const char *addr_txt, const int port) {// TODO: Y SI ESTA CONECTADO?

	WSADATA wsaData;
	net_ptr->new_socket = INVALID_SOCKET;//TODO: para que ?
	int ret;

	// Initialize Winsock
	//Inicializamos la DLL de sockets
	int wsOk = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (wsOk != 0) {
		printf("***CLIENT ERROR***: Can't Initialize windosk! Quitting \n");
		return -1;
	}

	// Create a socket 
	net_ptr->new_socket = socket(AF_INET, SOCK_STREAM, PROTOCOL_SOCKET);
	if (net_ptr->new_socket == INVALID_SOCKET) {
		wchar_t *s = NULL;
		FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL, WSAGetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPWSTR)&s, 0, NULL);
		printf("***CLIENT ERROR***: server_socket failed with error: %d - %S\n", WSAGetLastError(), s);
		LocalFree(s);
		WSACleanup();
		return -1;
	}
	// and set an ip address and port to a socket
	memset(&net_ptr->sockaddr_str, 0, sizeof(net_ptr->sockaddr_str));
	net_ptr->sockaddr_str.sin_port = htons(port);
	net_ptr->sockaddr_str.sin_family = AF_INET;

	if (inet_pton(AF_INET, addr_txt, &net_ptr->sockaddr_str.sin_addr) <= 0) {
		printf("***CLIENT ERROR***: invalid address. Address not supported. \n");
		return -1;
	}

	// Connect to server
	ret = connect(net_ptr->new_socket, (struct sockaddr *) &net_ptr->sockaddr_str, sizeof(net_ptr->sockaddr_str));
	if (ret == SOCKET_ERROR) {
		wchar_t *s = NULL;
		FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL, WSAGetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPWSTR)&s, 0, NULL);
		printf("***CLIENT ERROR***: connect() failed with error: %d - %S\n", WSAGetLastError(), s);
		LocalFree(s);
		closesocket(net_ptr->new_socket);
		WSACleanup();
		return -1;
	}
	memset(net_ptr->rx_buffer, 0, SIZE_BUFFER_LONG_B);

	ret = HelloWorldTest(net_ptr);
	if (ret < 0) {
		printf("***CLIENT ERROR***: HelloWorld test not success.\n");
		closesocket(net_ptr->new_socket);
		WSACleanup();
		return -1;
	}
	printf("Client connected.\n");
	return 0;

}


int disconnect_zynq(net_t *net_ptr) {// Y SI NO ESTA CONECTADO?
	int ret = -1;
	// No longer need server socket
	closesocket(net_ptr->new_socket);
	// shutdown the connection since we're done
	ret = shutdown(net_ptr->new_socket, SD_SEND);
	if (ret == SOCKET_ERROR) {
		wchar_t *s = NULL;
		FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL, WSAGetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
			(LPWSTR)&s, 0, NULL);
		printf("shutdown failed with error: %d - %S\n", WSAGetLastError(), s);
		LocalFree(s);
		closesocket(net_ptr->new_socket);
		WSACleanup();
		return ret;
	}
	// cleanup
	closesocket(net_ptr->new_socket);
	WSACleanup();
	ret = 0;
	return ret;
}
/************** RUN/STOP functions **************/
static int offset_store;
static int get_payload(fifo_data_t *rx_buffer, fifo_data_t * storage) {

	int i;
	//Extract only the payload
	/*for (i = SIZE_HEADER; i < SIZE_BUFFER_LONG -SIZE_CHECKSUM; i++){
	store[i-SIZE_HEADER] = rx_buffer[i];
	}*/
	//All
	for (i = 0; i < SIZE_BUFFER_LONG; i++) {		
		storage[offset_store + i] = rx_buffer[i];
	}
	offset_store = offset_store + SIZE_BUFFER_LONG;

	return 0; // return 0 if success, other if fail
}

/* RUN/STOP acquisition (axi-scope-1.0) */
int run_acq(net_t *net_ptr, fifo_data_t * storage) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available run_acq.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;
	int n = 0;

	net_ptr->streaming_mode = 1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_RUN);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_RUN_ACQ);
	net_ptr->param = SET_PARAM(API_ON);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);
	offset_store = 0;//FIXME
	do {
		// obtain data
		ret_r = read_bram(net_ptr);
		// save data
		get_payload(net_ptr->rx_buffer, storage);

		// send OK, continue
		net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
		net_ptr->cmd_us = SET_CMD_US(CMD_US_OK);
		net_ptr->cmd_ldd = SET_CMD_LDD(NONE);
		net_ptr->param = SET_PARAM(NONE);
		net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
		net_ptr->value_reg = NONE;

		n++;
		printf("***CLIENT INFO***: %d.\n", n);
		if (n >= TAM) {//FIXME
			printf("***CLIENT INFO***: Stop Streaming.\n");
			break;
		}
		ret_w = write_reg(net_ptr);

	} while ((!ret_r) || (!ret_w));

	return ret_w | ret_r; // return 0 if success, other if fail
}

int stop_acq(net_t *net_ptr) {
	if (!net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode OFF. "
			"Not available stop_acq.\n", __func__);
		return -1;
	}
	int ret_w = -1;

	net_ptr->streaming_mode = 0;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_STOP);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_RUN_ACQ);
	net_ptr->param = SET_PARAM(API_OFF);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);

	return ret_w;  // return 0 if success, other if fail
}

/************** SET functions **************/

/* Core enable (axi-scope-1.0) */
int set_core_enable_on(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_CORE_ENABLE);
	net_ptr->param = SET_PARAM(API_ON);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}
int set_core_enable_off(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_CORE_ENABLE);
	net_ptr->param = SET_PARAM(API_OFF);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Enable interrupts (axi-scope-1.0) */
int set_int_enable_on(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_INT_ENABLE);
	net_ptr->param = SET_PARAM(API_ON);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}
int set_int_enable_off(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_INT_ENABLE);
	net_ptr->param = SET_PARAM(API_OFF);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Sofware reset( axi-scope-1.0) */
int set_soft_reset_on(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_SW_RESET);
	net_ptr->param = SET_PARAM(API_ON);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}
int set_soft_reset_off(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_SW_RESET);
	net_ptr->param = SET_PARAM(API_OFF);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Set single mode (axi-scope-1.0) */
int set_single_mode_on(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_SINGLE_MODE);
	net_ptr->param = SET_PARAM(API_ON);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}
int set_single_mode_off(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_SINGLE_MODE);
	net_ptr->param = SET_PARAM(API_OFF);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = ONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Set trigger mode (axi-scope-1.0) */
int set_trimod_continuous(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_TRIGGER_MODE);
	net_ptr->param = SET_PARAM(API_OFF);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = CONTINUOUS;//Only two bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}
int set_trimod_rising(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_TRIGGER_MODE);
	net_ptr->param = SET_PARAM(API_OFF);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = CONTINUOUS;//Only two bit
									//First clean register
	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);
	if (ret_w || ret_r) {
		return -1; // return fail
	}
	//Second set register
	net_ptr->value_reg = RISING_EDGE;//Only two bit
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->param = SET_PARAM(API_ON);
	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);
	return ret_w | ret_r; // return 0 if success, other if fail
}
int set_trimod_falling(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_TRIGGER_MODE);
	net_ptr->param = SET_PARAM(API_OFF);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = CONTINUOUS;//Only two bit
									//First clean register
	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);
	if (ret_w || ret_r) {
		return -1; // return fail
	}
	//Second set register
	net_ptr->param = SET_PARAM(API_ON);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = FALLING_EDGE;//Only two bit
	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);
	return ret_w | ret_r; // return 0 if success, other if fail
}
int set_trimod_both(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_TRIGGER_MODE);
	net_ptr->param = SET_PARAM(API_OFF);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = CONTINUOUS;//Only two bit
									//First clean register
	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);
	if (ret_w || ret_r) {
		return -1; // return fail
	}
	//Second set register
	net_ptr->param = SET_PARAM(API_ON);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = BOTH_EDGE;//Only two bit
	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);
	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Set Interrupt Enable Register (axi-scope-1.0) */
int set_int_enable_reg(net_t *net_ptr, uint32_t arg) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_INT_ENEBLE_REG);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = arg;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Set Interrupt Flags Register (axi-scope-1.0) */
int set_int_flag_reg(net_t *net_ptr, uint32_t arg) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_INT_FLAG_REG);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = arg;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Set acquisition period time, this value depends on Zynq frequency (axi-scope-1.0) */
int set_acq_period_reg(net_t *net_ptr, uint32_t arg) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_ACQ_PERIOD);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = arg;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Set trigger level Register (axi-scope-1.0) */
int set_trilevel_reg(net_t *net_ptr, uint32_t arg) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_TRIGGER_LEVEL);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = arg;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Clean all IP registers  */
int set_clean_reg(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_CLEAN_REGS);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Set default registers */
int set_default_reg(net_t *net_ptr) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_DEFAULT_REGS);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}


/* Back door to write/read register*/
/* This function sets 32bit generic register into first 2 MB.
* @param index - num of register.
* @param arg - Data to write into register.
* @return - 0 if success, other if fail
* Note: see "Index of Registers 32 bits" in common.h file to see examples of register number.
*/
int set_generic_reg(net_t *net_ptr, uint32_t index, uint32_t arg)
{
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_SET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_BD_REG);
	net_ptr->param = SET_PARAM(index);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = arg;

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	return ret_w | ret_r; // return 0 if success, other if fail
}


/************** GET functions **************/

/* Core enable (axi-scope-1.0) */
int get_core_enable(net_t *net_ptr, uint32_t *data) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_GET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_CORE_ENABLE);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	*data = net_ptr->rx_buffer[2];

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Enable interrupts (axi-scope-1.0) */
int get_int_enable(net_t *net_ptr, uint32_t *data) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_GET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_INT_ENABLE);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	*data = net_ptr->rx_buffer[2];

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Sofware reset( axi-scope-1.0) */
int get_soft_reset(net_t *net_ptr, uint32_t *data) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_GET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_SW_RESET);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	*data = net_ptr->rx_buffer[2];

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Get single mode (axi-scope-1.0) */
int get_single_mode(net_t *net_ptr, uint32_t *data) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_GET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_SINGLE_MODE);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	*data = net_ptr->rx_buffer[2];

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Get trigger mode (axi-scope-1.0) */
int get_trigger_mode(net_t *net_ptr, uint32_t *data) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_GET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_TRIGGER_MODE);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	*data = net_ptr->rx_buffer[2];

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Get Interrupt Enable Register (axi-scope-1.0) */
int get_int_enable_reg(net_t *net_ptr, uint32_t *data) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_GET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_INT_ENEBLE_REG);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	*data = net_ptr->rx_buffer[2];

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Get Interrupt Flags Register (axi-scope-1.0) */
int get_int_flag_reg(net_t *net_ptr, uint32_t *data) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_GET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_INT_FLAG_REG);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	*data = net_ptr->rx_buffer[2];

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Get acquisition period time (axi-scope-1.0) */
int get_acq_period_reg(net_t *net_ptr, uint32_t *data) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_GET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_ACQ_PERIOD);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	*data = net_ptr->rx_buffer[2];

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Get trigger level (axi-scope-1.0) */
int get_trilevel_reg(net_t *net_ptr, uint32_t *data) {
	if (net_ptr->streaming_mode) {
		printf("***CLIENT WARNING***: psc-api.c: %s: Streaming mode ON. "
			"Not available get or set.\n", __func__);
		return -1;
	}
	int ret_w = -1;
	int ret_r = -1;

	net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
	net_ptr->cmd_us = SET_CMD_US(CMD_US_GET);
	net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_TRIGGER_LEVEL);
	net_ptr->param = SET_PARAM(NONE);
	net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
	net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);

	*data = net_ptr->rx_buffer[2];

	return ret_w | ret_r; // return 0 if success, other if fail
}

/* Back door to write/read register*/
/* This function gets 32bit generic register into first 2 MB.
* @param index - num of register.
* @param *data - A pointer to data read.
* @return - 0 if success, other if fail
* Note: see "Index of Registers 32 bits" in common.h file to see examples of register number.
*/
int get_generic_reg(net_t *net_ptr, uint32_t index, uint32_t *data)
{
	int ret_w = -1;
	int ret_r = -1;

  net_ptr->magic_num = SET_MAGIC_NUM(MAGIC_NUM_CLIENT);
  net_ptr->cmd_us = SET_CMD_US(CMD_US_GET) ;
  net_ptr->cmd_ldd = SET_CMD_LDD(CMD_LDD_BD_REG) ;
  net_ptr->param = SET_PARAM(index);
  net_ptr->cmd_full = SET_CMD_FULL(net_ptr->magic_num, net_ptr->cmd_us, net_ptr->cmd_ldd, net_ptr->param);
  net_ptr->value_reg = NONE;//Only a bit

	ret_w = write_reg(net_ptr);
	ret_r = read_reg(net_ptr);
  
  *data = net_ptr->rx_buffer[2];
  
  return ret_w | ret_r; // return 0 if success, other if fail
}

/************* Helps functions to Ethernet transfer **************/

/* This function obtains the checksum to be send it.
* @param socket - messafge.
* @return - 0 if success, other if fail
*/
static int checksum_opt(fifo_data_t *buff, int size) {

	fifo_data_t chks_sum = 0;
	int i = 0;
	//TODO REVISAR
	for (i = 0; i < size - 1; i++) {// only Header + Payload
									//printf("chks_sum = %08X, buff_ptr[i] = %08X \n", chks_sum, buff[i]);
		chks_sum = chks_sum + buff[i];
	}
	return chks_sum;
}

/* This function tests the checksum.
* @param socket - message.
* @return - 0 if success, other if fail.
*/
static int checksum_test(fifo_data_t *buff, int size)
{
	fifo_data_t chks_sum = 0;
	fifo_data_t chks_value = 0;
	int result = -1;

	//Obtein checksum send it
	chks_value = buff[size - 1];
	//Obtein checksum read it
	chks_sum = checksum_opt(buff, size);

	result = chks_sum - chks_value;

	return result;
}

/* This is a function to include timeout at recv_all().
* @param socket - Net Socket.
* @param *buffer - A pointer to data input buffer.
* @param length - Length of data to read.
* @param timeout - Timeout in seconds.
* @return - recv_all result.
*/
static int recvtimeout(int socket, fifo_data_t *buffer, int length, int timeout)
{
	fd_set fds;
	int n;
	struct timeval timeval_str;
	// Build the set of file descriptors
	FD_ZERO(&fds);
	FD_SET(socket, &fds);
	// Build the timeval structure of the timer
	timeval_str.tv_sec = timeout;
	timeval_str.tv_usec = 0;
	// Wait until data is received or the timer expires
	n = select(socket + 1, &fds, NULL, NULL, &timeval_str);
	if (n == 0) return -2; // The timer has expired! or the connection is closed
	if (n == -1) return -1; // Error
							// The data must be there, so I call recv_all()
							//return recv_all(socket, buffer, length, FLAG_READ);
	return readn(socket, (char*)buffer, length);
}

/* Safe function for SEND data
* @param socket - Net Socket.
* @param *buffer - A pointer to data output buffer.
* @param *length - A pointer to bytes send.
* @param flags - Flag for recv().
* @return - Return -1 if fail, other case 0
*/
static int send_all(int socket, fifo_data_t *buffer, int *length, int flags)
{
	int total = 0;  //How many bytes we have been send
	int bytesleft = *length;  //How many bytes are pending
	int n;
	while (total < *length)
	{
		n = send(socket, (char*)buffer + total, bytesleft, flags);
		if (n == -1) { break; } //And show error
		total += n;
		bytesleft -= n;
	}
	printf("CLIENT--->: numero de bytes enviados: %d\n", total);
	*length = total; //Return number of bytes send
	return n == -1 ? -1 : 0;
}

/* This is a function to WRITE REGISTERS of SoC Hardware.
* @param *net_ptr - A pointer to net struct.
* @return - It returns 0 if successful. -1 in case of error.
*/
int write_reg(net_t *net_ptr)
{
	int ret = -1;

	// Set length in 32 bits word
	net_ptr->wx_buffer[0] = SIZE_BUFFER_SHORT_B;
	// Set command
	net_ptr->wx_buffer[1] = net_ptr->cmd_full;
	// Set data
	net_ptr->wx_buffer[2] = net_ptr->value_reg;
	// Set checksum
	net_ptr->wx_buffer[3] = checksum_opt(net_ptr->wx_buffer, SIZE_BUFFER_SHORT);

	// Set transfer length in bytes
	net_ptr->valsend = SIZE_BUFFER_SHORT_B;

	//Send message
	if ((net_ptr->valsend = send_all(net_ptr->new_socket, net_ptr->wx_buffer,
		&(net_ptr->valsend), FLAG_SEND)) < 0) {
		printf("***CLIENT ERROR***: psc-api.c: send failed with error: %d\n", WSAGetLastError());
		closesocket(net_ptr->new_socket);
		WSACleanup();
		return -1;
	}
	else {
		ret = 0;
	}

	memset(net_ptr->wx_buffer, 0, SIZE_BUFFER_SHORT_B);

	return ret; // return 0 if success, -1 if fail
}

/* This is a function to READ REGISTERS from SoC Hardware.
* @param *net_ptr - A pointer to net struct. Save data in rx_buffer.
* @return - It returns 0 if successful. -1 in case of error.
*/
int read_reg(net_t *net_ptr)
{
	int ret = -1;
	int ret_ch = -1;
	int ret_ack = -1;
	int i;

	// Read response
	memset(net_ptr->rx_buffer, 0, SIZE_BUFFER_SHORT_B);
	net_ptr->valread = 0;

	do {
		if ((net_ptr->valread = recvtimeout(net_ptr->new_socket, net_ptr->rx_buffer,
			SIZE_BUFFER_SHORT_B, TIMEOUT)) == SOCKET_ERROR) {
			printf("***CLIENT ERROR***: psc-api.c: recv failed with error : %d\n", WSAGetLastError());
			return -1;
		}
		else if (net_ptr->valread == 0) {
			printf("***CLIENT ERROR***: psc-api.c: %s: Value read 0. Connection lost.\n", __func__);
		}
		else if (net_ptr->valread == -2) {
			printf("***CLIENT INFO***: The server timed out waiting for the request.\n");
		}
		else {
			//ret = 0;
		}
	} while (net_ptr->valread == -2);// repeat in case of time out warning

  //Test transaction
	ret_ch = checksum_test(net_ptr->rx_buffer, SIZE_BUFFER_SHORT);
	ret_ack = net_ptr->rx_buffer[1] & ACK_CMD_PROCESSED;
	if ((ret_ack == ACK_CMD_PROCESSED) && (ret_ch == 0)) {
		ret = 0;
		printf("***CLIENT INFO***: Read OK. \n");
	}
	else {
		printf("***CLIENT WARNING***: psc-api.c: %s: Fail in LDD read. \n", __func__);
	}

	// See data reading FIXME: delete
	printf("CLIENT: Message read: \n");
	printf("%s: net_ptr->rx_buffer: ", __func__);
	for (i = 0; i < SIZE_BUFFER_SHORT; i++) {
		printf("%08X ", net_ptr->rx_buffer[i]);
	}
	printf("\n");

	return ret;
}

/* This is a function to READ BRAM data from SoC.
* @param *net_ptr - A pointer to net struct. Save data in rx_buffer.
* @return - It returns 0 if successful. -1 in case of error.
*/
int read_bram(net_t *net_ptr)
{
	int ret = -1;
	int ret_ch = -1;
	int ret_ack = -1;
	int i;

	// Read response
	memset(net_ptr->rx_buffer, 0, SIZE_BUFFER_LONG_B);
	net_ptr->valread = 0;

	do {
		if ((net_ptr->valread = recvtimeout(net_ptr->new_socket, net_ptr->rx_buffer,
			SIZE_BUFFER_LONG_B, TIMEOUT)) == SOCKET_ERROR) {
			printf("***CLIENT ERROR***: psc-api.c: recv failed with error : %d\n", WSAGetLastError());
			return -1;
		}
		else if (net_ptr->valread == 0) {
			printf("***CLIENT ERROR***: psc-api.c: %s: Value read 0. Connection lost.\n", __func__);
		}
		else if (net_ptr->valread == -2) {
			printf("***CLIENT INFO***: The server timed out waiting for the request.\n");
		}
		else {
			//ret = 0;
		}
	} while (net_ptr->valread == -2);// repeat in case of time out warning


	//Test transaction
	ret_ch = checksum_test(net_ptr->rx_buffer, SIZE_BUFFER_LONG);
	ret_ack = net_ptr->rx_buffer[1] & ACK_CMD_PROCESSED;
	if ((ret_ack == ACK_CMD_PROCESSED) && (ret_ch == 0)) {
		ret = 0;
		printf("***CLIENT INFO***: Read OK. \n");
	}
	else {
		printf("***CLIENT WARNING***: psc-api.c: %s: Fail in LDD read. ret_ch=%d ,ret_ack=%d \n", __func__, ret_ch, ret_ack);
	}

	// See data reading FIXME: delete
	printf("CLIENT: Message read: \n");
	printf("%s: net_ptr->rx_buffer: ", __func__);
	for (i = 0; i < SIZE_BUFFER_LONG; i++) {
		printf("%08X ", net_ptr->rx_buffer[i]);
	}
	printf("\n");

	return ret;
}

/* This  function sava stogare data.
* @param *storage - A pointer to storage data.
* @param count - Number of elements to write.
* @param *pFIle - A pointer to path file.
* @return - It returns 0 if successful. -1 in case of error.
*/
int save_storage(fifo_data_t *storage, int count, const char *pFIle) {

	int ret = -1;
	FILE *filepoint;
	errno_t err;

	if ((err = fopen_s(&filepoint, pFIle, "w+b")) != 0) {
		// File could not be opened. filepoint was set to NULL
		// error code is returned in err.
		// error message can be retrieved with strerror(err);
		printf("***CLIENT ERROR***:cannot open file '%s': %s\n",
			pFIle, err);
		return -1;
	}else {
		// File was opened, filepoint can be used to read the stream.
	}
	ret = fwrite(storage, sizeof(fifo_data_t), count, filepoint);
	ret = fclose(filepoint);
	return ret;
}


