/* 0LOG.txt
 * Edel D�az Llerena
 * Universidad de Alcal�
 * 22/10/2018
 */
## 
## Organizaci�n del repositorio:
##
  /HW --> carpeta con todo lo relevante al HW: Linux Empotrado y HW-Vivado.
  /../hw_repo/ --> proyecto Vivado.
  /../hw_proj/ --> IPs a medida.
  /SW --> carpeta con todo lo relevante al SW: Cliente y Servidor.
  /../Windows --> Cliente.
  /../Linux --> Servidor y Sistema Operativo.
  /doc --> carpeta con documentaci�n importante.
