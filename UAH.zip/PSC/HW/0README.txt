/* 0README.txt
 * Edel D�az Llerena
 * Universidad de Alcal�
 * 06/11/2018
 */
##
## Organizaci�n del repositorio:
##
  /hw_repo --> carpeta donde los IPS a medida para el proyecto.
  /hw_proj --> carpeta donde esta el proyecto de Vivado y ficheros .hdf y .bit