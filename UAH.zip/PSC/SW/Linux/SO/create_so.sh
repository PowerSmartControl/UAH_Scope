#!/bin/bash
######
# Edel Díaz Llerena.
# University of Alcala.
######
# PSC Project. 
# 09/11/2018.
######
clear
set -e
echo ""
echo "Running file: create_so.sh"
# Configurar en funciónd e los datos de cada Usuario.

path_settings="/opt/petalinux/petalinux-v2017.4"
path_project="."
path_files="."
name_prj="psc_linux"

path_bitstream="/home/edel.diaz/projects/psc-scope/vivado/linux-test-scope/vivado_2017/linux-test-scope.runs/impl_1/design_1_wrapper.bit"

path_hdf="/home/edel.diaz/projects/psc-scope/vivado/linux-test-scope/vivado_2017/linux-test-scope.sdk/design_1_wrapper.hdf"

path_to_SD="/run/media/edel.diaz/BOOT"


# Cargar comandos petalinux
source $path_settings/settings.sh
#source /opt/petalinux/petalinux-v2016.4/settings.sh
#source /opt/petalinux/petalinux-v2015.4-final/settings.sh
# ERROR: Failed to source bitbake
# ERROR: Failed to config project.
# Solved:
#source /opt/petalinux/petalinux-v2017.4/components/yocto/source/aarch64/environment-setup-aarch64-xilinx-linux

cd $path_project

# Creación del proyecto: proyecto tipo “zynq” denominado como <name_project>
petalinux-create --type project --template zynq --name $name_prj

# Configuracion del proyecto:
# 1 - Crear carpeta denominada como hw en la carpeta del proyecto PetaLinux(<name_project>).
cd $name_prj
mkdir -m 777 hw

# 2 - Copiar en hw/ los 2 ficheros bitstream y hdf del HW.
# bitstream: <project-name>.runs/impl_<number>/<block-design-name>_wrapper.bit
# hdf: <project-name>.sdk/<block-design-name>_wrapper.hdf
cp $path_bitstream ./hw/

cp $path_hdf ./hw/
echo ""
echo ".BIT Y .HDF COPIADOS"
echo ""

# 3 - Configuración del proyecto con el hardware exportado.
# 3.1 - En este apartado configurar:
# - Configuración del tipo de sistema de archivos -> INITRAMFS. Este tipo de sistema de archivos se carga en RAM nada más arrancar el sistema. De esta forma se puede alargar la vida útil de la tarjeta SD: 
#   + Image Packaging Configuration>Rootfile System type>INITRAMFS

# - Configuracion de Ehternet.
#   + Sysbystem AUTO Hardware Settings>Ethernet Settings>Obtain IP address automatically (actived)

# - Configuracion de fuente de arranque de imagen y kernel desde SD y nombres: 
#   + Sysbystem AUTO Hardware Settings>Advanced bootable images storage Settings>boot image settings>image storage media> primary sd
#   + Sysbystem AUTO Hardware Settings>Advanced bootable images storage Settings>boot image settings>image name>BOOT.BIN
#   + Sysbystem AUTO Hardware Settings>Advanced bootable images storage Settings>kernel image settings>image storage media> primary sd
#   + Sysbystem AUTO Hardware Settings>Advanced bootable images storage Settings>kernel image settings>image name>image.ub
petalinux-config --get-hw-description=./hw

# 3.2 - Configurar el kernel. NOTA: NO NECESARIO, SI NO SE EJECUTA EL COMANDO SE TOMA POR DEFECTO.
#petalinux-config -c kernel

# 3.3- Añadir librerías y herramientas necesarias para el desarrollo del proyecto. NOTA: CUANTO MENOS LIBRERÍAS SE INCORPOREN MENOS PESADA SERÁ LA IMAGEN Y MÁS SEGURA. NO NECESARIO, SI NO SE EJECUTA EL COMANDO, SE TOMA POR DEFECTO.
#petalinux-config -c rootfs

# 4 - Añadir script inicial de arranque.
petalinux-create -t apps --template install -n bootscript --enable

# 4.1 - Modificar el fichero de arranque
#$path_project/$name_prj/project-spec/meta-user/recipes-apps/bootscript/files/bootscript.sh

# 4.2 - Modificar el fichero de compilacion de bootscript 
#$path_project/$name_prj/project-spec/meta-user/recipes-apps/bootscript/bootscript.bb
#Modificaciones de bootscript.bb: (+) = añadido (-) eliminado.
#...
#+inherit update-rc.d
#
#+INITSCRIPT_NAME = "bootscript"
#+INITSCRIPT_PARAMS = "start 99 S ."
#
#do_install() {
#	     -install -d ${D}/${bindir}
#	     -install -m 0755 ${S}/bootscript ${D}/${bindir}
#	     +install -d ${D}/${sysconfdir}/init.d
#	     +install -m 0755 ${S}/bootscript ${D}/${sysconfdir}/init.d/bootscript
#}
#
#+FILES_${PN} += "${sysconfdir}/*"
cp -r ../files2patch/recipes-apps/bootscript ./project-spec/meta-user/recipes-apps


# 5 - Adaptar el Device Tree.
# Modificar el fichero $path_project/$name_prj/project-spec/meta-user/recipes-bsp/device-tree/files/system-user-dtsi:

#/include/ "system-conf.dtsi"
#/ {
#
#	amba_pl: amba_pl {
#		#address-cells = <0x1>;
#		#size-cells = <0x1>;
#		compatible = "simple-bus";
#		ranges;
#
#		axi_scope@40000000 {
#			compatible = "uah,axi-scope-1.0";
#			interrupt-parent = <0x4>;
#			interrupts = <0x0 0x1d 0x4>;
#			reg = <0x40000000 0x00200000>;
#			xlnx,din-width = <0x70>;
#			xlnx,trigger-width = <0x10>;
#		};
#	};
#};
cp -r ../files2patch/recipes-bsp/device-tree ./project-spec/meta-user/recipes-bsp

# 6 - Pre-Compilación 
# 6.1 - Compilación del kernel proporcionado por PetaLinux.
petalinux-build -c kernel

# 6.2 - Compilacion del script de arranque.
petalinux-build -c bootscript -x do_install -f
petalinux-build -c bootscript
petalinux-build -c rootfs
petalinux-build -x package
# 6.3 - Primera compilación del sistema completo.
petalinux-build

# 7 - Incluir Linux Device Driver (LDD). UG1144(v2017.2) Pag. 54
petalinux-create -t modules --name psc-ldd --enable
# 7.1 añadir ficheros psc-ldd.c, common.h y psc-ldd.h en $path_project/project-spec/meta-user/recipes-modules/psc-ldd/files
# 7.2 Modificar psd-ldd.bb para incluir los ficheros del LDD
#...
#SRC_URI = "file://Makefile \
#           file://psc-ldd.c \
#	    file://common.h \
#           file://psc-ldd.h \
#	    file://COPYING \
#          "
#...
rm ./project-spec/meta-user/recipes-modules/psc-ldd/files/psc-ldd.c
cp -r ../files2patch/recipes-modules/psc-ldd ./project-spec/meta-user/recipes-modules

# 8 - RE-Compilacion de kernel para incluir el LDD
petalinux-build -c kernel
petalinux-build -c psc-ldd
petalinux-build -x package
petalinux-build 

# 9 - Crear ficheros de arranque para la tarjeta SD.
path_to_bit=./hw/design_1_wrapper.bit
petalinux-package --prebuilt --force --fpga $path_to_bit

# Generar la imagen de arranque en formato .BIN
path_to_elf=./images/linux/zynq_fsbl.elf
petalinux-package --boot --fsbl $path_to_elf --fpga  --uboot --force -o images/linux/BOOT.BIN

# 10 - Copiar ficheros a SD
cp ./images/linux/image.ub $path_to_SD/image.ub
cp ./images/linux/BOOT.BIN $path_to_SD/BOOT.BIN
echo " "
echo "### FICHEROS COPIADOS A BOOT ###"
echo " "
# Los ficheros generados: copiar los dos en particion BOOT en SD
# en image/linux
# 	BOOT.bin: arranque del Linux.
# 	Image.ub: imagen de kernel de Linux RAMFS.

# Particiones de SD (utilizar herramienta gparted):
# 1- Partición de arranque:
#Espacio precedente: 4Mb.
#Tamaño: 512Mb. 
#Tipo: Primaria. 
#Formato: FAT32. 
#Nombre: BOOT.

# 2- Partición de datos:
#Tamaño: espacio restante.
#Tipo: Primaria. Formato: FAT32.
#Nombre: ROOTFS.


exit
#############################DEBUG################################
# Para actualizar el script de inicio:
petalinux-build -c kernel
petalinux-build -c bootscript -x do_install -f
petalinux-build -c rootfs
petalinux-build -x package
petalinux-build 


# Para actualizar el LDD:
petalinux-build -c kernel
petalinux-build -c psc-ldd
petalinux-build -x package
petalinux-build 

# Para actualizar el kernel:
petalinux-build -c kernel
petalinux-build -x package
petalinux-build 


#############################HELPS################################

#petalinux-build
#EXAMPLES:

#Build the project:
#  $ petalinux-build
#  the bootable images are in <PROJECT>/images/linux/.

#Build kernel only:
#  $ petalinux-build -c kernel

#Compile kernel forcefully:
#  $ petalinux-build -c kernel -x compile -f

#Deploy kernel forcefully:
#  $ petalinux-build -c kernel -x deploy -f

#Build kernel and update the bootable images:
#  $ petalinux-build -c kernel
#  $ petalinux-build -x package

#Build rootfs only:
#  $ petalinux-build -c rootfs

#Build myapp of rootfs only:
#  $ petalinux-build -c rootfs/myapp

#List all rootfs sub-components:
#  $ petalinux-build -c rootfs -h

#Clean up u-boot and build again:
#  $ petalinux-build -c u-boot -x distclean
  ## above command will remove the <PROJECT>/build/linux/u-boot/ directory.
#  $ petalinux-build -c u-boot

#Clean up the project build and build again:
#  $ petalinux-build -x distclean
  ## above command will remove the <PROJECT>/build/ directory.
#  $ petalinux-build

#Clean up the project build and the generated bootable images:
#  $ petalinux-build -x mrproper
  ## above command will remove <PROJECT>/images/ and <PROJECT>/build/ directories

#petalonux-config
#EXAMPLES

#Sync hardware description:

#Sync hardware description from Vivado export to PetaLinux BSP project:
#  $ cd <Vivado_Export_to_SDK_Directory>
#  $ petalinux-config --get-hw-description
#  It will sync up the XML file and ps7_init.c/.h for Zynq from
#  <Vivado_Export_to_SDK_Directory> to project-spec/hw-description/ directory.

#Sync hardware description inside PetaLinux project but outside Vivado epxort to SDK directory:
#  $ petalinux-config --get-hw-description=<Vivado_Export_to_SDK_Directory>


#Configure PetaLinux project:

#Configure subsystem level configuration:
#  $ petalinux-config

#Configure kernel:
#  $ petalinux-config -c kernel

#Configure rootfs:
#  $ petalinux-config -c rootfs

#Defconfig kconfig kernel with xilinx_zynq_base_trd_defconfig:
#  $ petalinux-config -c kernel --defconfig xilinx_zynq_base_trd_defconfig

#Example to create projects:
#From PetaLinux Project BSP:
#$ petalinux-create -t project -s <PATH_TO_PETALINUX_PROJECT_BSP>
#From template:
#$ petalinux-create -t project -n <PROJECT> --template zynq
#Example to create apps:
#Create an app and enable it:
#$ petalinux-create -t apps -n myapp --enable
#The application "myapp" will be created with c template in:
#<PROJECT>/components/apps/myapp/
#Example to create libs:
#Create an lib and enable it:
#$ petalinux-create -t libs -n mylib --enable
#The library "mylib" will be created with c template in:
#<PROJECT>/components/libs/mylib/
#Example to create moduless:
#Create an lib and enable it:
#$ petalinux-create -t modules -n mymodule --enable
#The library "mymodule" will be created with template in:
#<PROJECT>/components/modules/mymodule/



