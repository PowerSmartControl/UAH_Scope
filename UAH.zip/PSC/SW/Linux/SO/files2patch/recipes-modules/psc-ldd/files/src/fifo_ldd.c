/*  fifo.h - Fifo help functions
******************
* Edel Diaz Llerena
* 01/06/2018
* University of Alcala
******************
* Description:

******************
* Change log:
******************
*/

/* INCLUDES */
#include "fifo_ldd.h"
#include "common_ldd.h" // debug and ldd names

/* COMPILER */
//#define DEBUG_FIFO      // Disable to not show printks
#ifdef DEBUG_FIFO
 #define dbg_printk(format, arg...)	\
	printk(format, ## arg);
#else
 #define dbg_printk(format, arg...)
#endif

/* FUNCTIONS */
/******************* FIFO Help functions ******************/

/* This function is called when init this driver, i.e. __init function. Set fifo
 * and SpinLock.
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
int fifo_init(fifo_t *q) {
  q->rd_idx = q->wr_idx = 0;
  q->cnt = 0;
  // file wait.h
  // void init_waitqueue_head(wait_queue_head_t *q)
  init_waitqueue_head(&q->wait_on_rd);
  spin_lock_init(&q->queue_lock); 
  //dbg_printk(  "psc-ldd: %s: init fifo and spinlock OK.\n",__FUNCTION__);
  return 0;
}

/* This function is called whenever it read this driver from user space.
 * It is used for test if threa are data into fifo. 
 * @param *q - A pointer to fifo struct.
 * @return - It returns 1 if fifo is empty
 */
int fifo_empty(fifo_t *q) {
  int ret;
  spin_lock(&q->queue_lock);
  ret = (q->cnt == 0); 
  //dbg_printk(  "psc-ldd: %s:init fifo and spinlock OK.\n",__FUNCTION__);
  spin_unlock(&q->queue_lock);
  return ret;
}

/* This function is called whenever it read this driver from user space. 
 * @param *q - A pointer to fifo struct.
 * @return - It returns number of events into fifo.
 */
int fifo_count(fifo_t *q) {
  int ret;
  spin_lock(&q->queue_lock);
  ret = q->cnt; 
  //dbg_printk(  "psc-ldd: %s:\n",__FUNCTION__);
  spin_unlock(&q->queue_lock);
  return ret;
}

/* This function is called whenever it read this driver from user space. 
 * Fifo data is send to driver_read() function.
 * @param *q - A pointer to fifo struct.
 * @param *data - A pointer to buffer to read from user space. Typically uint32_t.
 * @return - It returns 0 if successful.
 */
int fifo_get(fifo_t *q, fifo_data_t *data) {
  int ret;
  
	spin_lock(&q->queue_lock);
  if(q->cnt != 0) {
    *data = q->data[q->rd_idx];
    q->rd_idx = (q->rd_idx == FIFO_SIZE-1)? 0 : q->rd_idx + 1;
    q->cnt--;
    ret = 1;
  }
  else {
    *data = 0;
    ret = 0;  
  }
  //dbg_printk(  "psc-ldd: %s: READ cnt = %i, rd_idx = %i.\n",__FUNCTION__, q->cnt, q->rd_idx);
  spin_unlock(&q->queue_lock);
  return ret;
}

/* This function is called whenever an irq occurs. It copies BRAM data from 0 to
 * BRAM_DATA_SIZE into queue. It also increases wr_idx and cnt indexes
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
int fifo_put(fifo_t *q, fifo_data_t *base_address) {
  int ret, i;

  spin_lock(&q->queue_lock);
  for ( i = BRAM_ADDR_MIN; i   < BRAM_ADDR_MAX; i++ ) {
    if(q->cnt < FIFO_SIZE) {
      q->data[q->wr_idx] = base_address[i];
      q->wr_idx = (q->wr_idx == FIFO_SIZE-1)? 0 : q->wr_idx + 1;
      q->cnt++;
      ret = 1;
    } else {
      //dbg_printk("psc-ldd: [%s] rebose on put\n", __FUNCTION__);
      ret = 0; 
    }     
  }   
  //dbg_printk(  "psc-ldd: %s: WRITE cnt = %i, wr_idx = %i.\n",__FUNCTION__, q->cnt, q->wr_idx);
  spin_unlock(&q->queue_lock);
  return ret;
}

/* This function is called whenever it opens this driver from user space. 
 * It cleans de index of event queue or fifo.
 * @param *q - A pointer to fifo struct.
 * @return - It returns 0 if successful.
 */
int fifo_flush(fifo_t *q) {
  spin_lock(&q->queue_lock);
  q->rd_idx = q->wr_idx = 0;
  q->cnt = 0;
  dbg_printk(  "psc-ldd: %s: fifo cleaned.\n",__FUNCTION__);
  spin_unlock(&q->queue_lock);
  return 0;
}

