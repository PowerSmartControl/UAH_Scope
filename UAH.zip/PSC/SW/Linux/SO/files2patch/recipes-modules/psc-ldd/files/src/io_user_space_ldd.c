/*  io_user_space_ldd.c - I/O functon to talk with User Space
******************
* Edel Diaz Llerena
* 01/06/2018
* University of Alcala
******************
* Description:
* In this file is open(), read(), write(), ioctl() and close() 
* functions that run as callbacks from User Space.
******************
* Change log:
******************
*/
/* INCLUDES */
#include "io_user_space_ldd.h"
#include "common_ldd.h" // debug and ldd names

/* COMPILER */
//#define DEBUG_IO      // Disable to not show printks
#ifdef DEBUG_IO
 #define dbg_printk(format, arg...)	\
	printk(format, ## arg);
#else
 #define dbg_printk(format, arg...)
#endif

static fifo_t fifo_str;

static uint32_t *axi_scope_ptr_io;

/* FUNCTIONS */
/******************* Register HW Help functions ******************/

int default_hw_reg(uint32_t *base_address){
  
  base_address[INT_ENABLE_REG_INDEX] = 0x00000001;
  base_address[INT_FLAG_REG_INDEX] = 0x00000000;
  base_address[CTRL_REG_INDEX] = 0x00000022;
  base_address[ACQ_PERIOD_REG_INDEX] = 0x0000000A;
  base_address[TRIG_LEVEL_REG_INDEX] = 0xFFFFFF38;
  return 0; //Success
}

int clean_hw_reg(uint32_t *base_address){
  
  base_address[INT_ENABLE_REG_INDEX] = 0x00000000;
  base_address[INT_FLAG_REG_INDEX] = 0x00000000;
  base_address[CTRL_REG_INDEX] = 0x00000000;
  base_address[ACQ_PERIOD_REG_INDEX] = 0x00000000;
  base_address[TRIG_LEVEL_REG_INDEX] = 0x00000000;
  return 0; //Success
}

//TODO
int set_hw_reg(uint32_t *base_address, 
                      uint32_t reg_index,
                      uint32_t reg_shift,
                      unsigned int *arg, unsigned int param) {  
  int ok;
  int ret = 0;
  uint32_t write_data;
  
  ok = access_ok(VERIFY_READ, (void __user *)arg, sizeof (unsigned int));
  if(!ok) {
     dbg_printk(  "[indra_fmtr_ioctl_set_reg]  Error\n");
    return -EFAULT;
  }
  ret = __get_user(write_data, arg);

  if(reg_index > (MEM_RANGE-1)){
    return -1; //Out of range
  }
  if(param == NORMAL){// seria 1 o 0 ON o OFF// utilizo param para determinar la accion
    base_address[reg_index] = write_data;
    dbg_printk(  "psc-ldd: %s:\n"
                     "base_address[reg_index] = write_data;\n"
                     "%08X[%08X] = %08X\n"
		     "base_address[reg_index] = %08X\n"
                      ,__FUNCTION__,base_address,reg_index,write_data,
                      base_address[reg_index]);
  }else if(param == OR_OPT){    
    base_address[reg_index] |= (write_data << reg_shift);// poner a 1
    dbg_printk(  "psc-ldd: %s:\n"
                     "base_address[reg_index] |= (write_data << reg_shift);\n"
                     "%08X[%08X] &= ~(%08X << %08X)\n"
		     "base_address[reg_index] = %08X\n"
                      ,__FUNCTION__,base_address,reg_index,write_data,reg_shift,
                      base_address[reg_index]);
  }else if(param == AND_NOT_OPT){
    base_address[reg_index] &= ~(write_data << reg_shift);// poner a 0
    dbg_printk(  "psc-ldd: %s:\n"
                     "base_address[reg_index] &= ~(write_data << reg_shift);\n"
                     "%08X[%08X] &= ~(%08X << %08X)\n"
		     "base_address[reg_index] = %08X\n"
                      ,__FUNCTION__,base_address,reg_index,write_data,reg_shift,
                      base_address[reg_index]);


  }else{
    dbg_printk(  "psc-ldd: %s: No param detected\n",__FUNCTION__);
  }
  return 0; //Success
} 
//TODO
int get_hw_reg(uint32_t *base_address,
                      uint32_t reg_index,
                      uint32_t reg_mask,
                      uint32_t reg_shift,
                      unsigned int *arg) {
  int ok;
  int ret = 0;
  uint32_t read_data;

  ok = access_ok(VERIFY_WRITE, (void __user *)arg, sizeof (uint32_t));
  if(!ok) {
     dbg_printk(  "[indra_fmtr_ioctl_get_reg]  Error\n");
    return -EFAULT;
  }
  //read_data = 0xABCDEF1234;
  read_data = (base_address[reg_index] & reg_mask) >> reg_shift;
  ret = __put_user(read_data, arg);

  dbg_printk(  "psc-ldd: %s:\n"
                   "read_data = (base_address[reg_index] && reg_mask) >> reg_shift\n"
                   "%08X = (%08X[%08X] && %08X) >> %08X\n"
		   "base_address[reg_index] = %08X\n"
	 	   "base_address[reg_index] & reg_mask = %08X\n"
                    ,__FUNCTION__,read_data,base_address,reg_index,reg_mask,reg_shift,
                     base_address[reg_index],base_address[reg_index] & reg_mask);
  return ret;
} 

/******************* I/O functions ******************/

/* The device open function that is called each time the device is opened.
 * @param *inodep - A pointer to an inode object (defined in linux/fs.h).
 * @param *filep - A pointer to a file object (defined in linux/fs.h).
 * @return - It returns 0 if successful.
 */
int driver_open(struct inode *inodep, struct file *filep){
  dbg_printk(  "psc-ldd: device has been opened.\n");
  return 0;
};
 
/* This function is called whenever device is being read from user space i.e. 
 * data is being sent from the device to the user. In this case is uses the 
 * __put_user() function to send the buffer string to the user and captures any
 * errors.
 * @param *filep - A pointer to a file object (defined in linux/fs.h).
 * @param *buffer - The pointer to the buffer to which this function writes the 
 * data.
 * @param len - The length of the buffer in bytes.
 * @param *offset - The offset if required.
 * @return - It returns the size of data read.
 */
ssize_t driver_read(struct file *filep, char __user *buffer, size_t len, loff_t *offset){
  fifo_data_t fifo_data;
  fifo_data_t __user *buffer_ptr;
  uint32_t n_events, rqt_events;// number of events and number of request events
  int i, ok, ret, size;

  buffer_ptr = (fifo_data_t __user *) buffer;
  dbg_printk(  "psc-ldd: Reading...\n");  
  
  dbg_printk(  "psc-ldd: process %i (%s)is going to sleep, !fifo_empty(fifo_ptr)=%i\n", current->pid, current->comm, !fifo_empty(&fifo_str));
  // file: wait.h
  // int wait_event_interruptible(wait_queue_head_t q, condition);
  if (wait_event_interruptible(fifo_str.wait_on_rd, !fifo_empty(&fifo_str))) {
    return -ERESTARTSYS;
  }
  dbg_printk(  "psc-ldd: awoken %i (%s)\n", current->pid, current->comm);
  
  n_events = fifo_count(&fifo_str);// in words of 32 bits
  size = n_events * sizeof (fifo_data_t);
  dbg_printk(  "psc-ldd: len = %i, sizeof(fifo_data_t) =  %i\n", len, sizeof(fifo_data_t));
  rqt_events = len / sizeof (fifo_data_t);// in words of 32 bits
  dbg_printk(  "psc-ldd: n_events = %i, rqt_events =  %i\n", n_events, rqt_events);
  n_events = (rqt_events > n_events )? n_events : rqt_events;
  dbg_printk(  "psc-ldd: n_events_final = %i\n", n_events);
  size = n_events * sizeof (fifo_data_t);
   
  // Checks if a user space pointer is valid
  ok = access_ok(VERIFY_WRITE, buffer_ptr, size);
  if(!ok) {
    dbg_printk(  "psc-ldd: [%s] Error in acces_ok\n",__FUNCTION__);
    return -EFAULT;
  }

  for(i = 0; i < n_events; i++) {
    ret = fifo_get(&fifo_str, &fifo_data);
    if (ret){
      // Write a simple value into user space, with less checking.
      //  __put_user (x, ptr);
      //  @param x - Value to copy to user space.
      //  @param ptr - Destination address, in user space.
      if(__put_user(fifo_data, &buffer_ptr[i])) {
        dbg_printk(  "psc-ldd: [%s] Error in __put_user: &buffer_ptr[%d])\n",__FUNCTION__,i);
        return -EFAULT;
      }
    }
  } 
  //Ready for other interrupt
  axi_scope_ptr_io[CTRL_REG_INDEX] |= (1 << 7);
  dbg_printk(  "psc-ldd: [%s] Readed ENDED\n",__FUNCTION__);

  return size;
};
 
/* This function is called whenever the device is being written to from user 
 * space i.e. data is sent to the device from the user. 
 * @param *filep - A pointer to a file object.
 * @param *buffer - The buffer to that contains the string to write to the device.
 * @param len - The length of the array of data that is being passed in the 
 * const char buffer.
 * @param *offset - The offset if required.
 * @return - It returns the size of data has wrote.
 */
ssize_t driver_write(struct file *filep, const char __user *buffer, size_t len, loff_t *offset){
  uint32_t *u_buf;
  int i;
  uint32_t offset_kwrite = 0;// offset address in Write access
  dbg_printk(  "psc-ldd: driver_write\n");
  // Allocate kernel memory for pass buf to kernel space
  u_buf = kmalloc((len+1)*sizeof(uint32_t), GFP_KERNEL);

  // Pass buf to kernel space
  if (copy_from_user(u_buf, (uint32_t *)buffer, (len+1)*sizeof(uint32_t)) != 0)
        return -EFAULT;
        
  offset_kwrite = u_buf[0];	//offset is always at the head of user buffer
  dbg_printk(  "psc-ldd: offset:%d\n", u_buf[0]);
  for ( i = 0; i < len; i++ ) {
    axi_scope_ptr_io[i+offset_kwrite]  = u_buf[i+1];
    dbg_printk(  "psc-ldd: Reg driver write: offset %d len %d addr[%d]: %d\n", offset_kwrite, len, i+offset_kwrite, axi_scope_ptr_io[i+offset_kwrite]);
  }
  // Release allocated kernel memory
  kfree(u_buf);

  return len;
};

/* The ioctl function that is called whenever the device wants  send a CMD from 
 * User Space.
 * @param *filep - A pointer to a file object (defined in linux/fs.h).
 * @param srv - Command type input.
 * @param arg - Argument.
 * @return - It returns 0 if successful.
 */
/* IMPORTANT */
long driver_ioctl(struct file *filep, unsigned int srv, unsigned long arg){
 
  int ret = 0;
  uint32_t bd_index;
  
  unsigned int magic_num;
  unsigned int cmd_us;
  unsigned int cmd_ldd;
  unsigned int param ;
  
  // Obtain syntax from command type.
  magic_num = GET_MAGIC_NUM(srv);
  cmd_us = GET_CMD_US(srv);
  cmd_ldd = GET_CMD_LDD(srv);
  param = GET_PARAM(srv);
  
  dbg_printk(  "psc-ldd: %s: srv = %08X, magic_num = %02X, cmd_us = %02X,"
        "cmd_ldd = %02X, param = %02X\n", __FUNCTION__, srv, magic_num, cmd_us,
        cmd_ldd, param);
           
  switch(cmd_us) {
  /********************* CTRL User Space Packet decoding *********************/
  case CMD_US_SET: 
    switch(cmd_ldd) {
    /********************* CTRL LDD Packet decoding *********************/
    case CMD_LDD_CORE_ENABLE: // Core enable (axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_CORE_ENABLE\n", __FUNCTION__); 
      ret = set_hw_reg(axi_scope_ptr_io, 
                       CTRL_REG_INDEX,
                       CTRL_REG_CORE_ENABLE_SHIFT,
                      (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_SW_RESET: // Sofware reset( axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_SW_RESET\n", __FUNCTION__); 
      ret = set_hw_reg(axi_scope_ptr_io, 
                   CTRL_REG_INDEX,
                   CTRL_REG_SW_RST_SHIFT,
                  (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_SINGLE_MODE: // Set single mode (axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_SINGLE_MODE\n", __FUNCTION__); 
      ret = set_hw_reg(axi_scope_ptr_io, 
                   CTRL_REG_INDEX,
                   CTRL_REG_SINGLE_SHIFT,
                  (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_TRIGGER_MODE: // Set trigger mode (axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_TRIGGER_MODE\n", __FUNCTION__); 
      ret = set_hw_reg(axi_scope_ptr_io, 
                   CTRL_REG_INDEX,
                   CTRL_REG_TRIGGER_SHIFT,
                  (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_TRIGGER_LEVEL: // Set trigger level (axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_TRIGGER_LEVEL\n", __FUNCTION__); 
      ret = set_hw_reg(axi_scope_ptr_io, 
                   TRIG_LEVEL_REG_INDEX,
                   NO_SHIFT,
                  (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_INT_ENABLE: // Enable interrupts (axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_INT_ENABLE\n", __FUNCTION__);
      ret = set_hw_reg(axi_scope_ptr_io, 
                       CTRL_REG_INDEX,
                       CTRL_REG_INT_ENABLE_SHIFT,
                      (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }    
      break;
      
    case CMD_LDD_INT_ENEBLE_REG: // Set Interrupt Enable Resiter (axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_INT_ENEBLE_REG\n", __FUNCTION__); 
      ret = set_hw_reg(axi_scope_ptr_io, 
                   INT_ENABLE_REG_INDEX,
                   NO_SHIFT,
                  (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_INT_FLAG_REG: // Set Interrupt Enable register (axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_INT_FLAG_REG\n", __FUNCTION__); 
      ret = set_hw_reg(axi_scope_ptr_io, 
                   INT_FLAG_REG_INDEX,
                   NO_SHIFT,
                  (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_ACQ_PERIOD: // Set acquisition period time, this value depends on Zynq frequency (axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_ACQ_PERIOD\n", __FUNCTION__); 
      ret = set_hw_reg(axi_scope_ptr_io, 
                   ACQ_PERIOD_REG_INDEX,
                   NO_SHIFT,
                  (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_DEFAULT_REGS: // Set default registers// TODO
      dbg_printk(  "psc-ldd: %s: CMD_LDD_DEFAULT_REGS\n", __FUNCTION__); 
      ret = default_hw_reg(axi_scope_ptr_io);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: default_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_CLEAN_REGS: // Clean all IP registers //
      dbg_printk(  "psc-ldd: %s: CMD_LDD_CLEAN_REGS\n", __FUNCTION__); 
      ret = clean_hw_reg(axi_scope_ptr_io);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: clean_hw_reg .\n", __FUNCTION__);
      }
      break;
      
    case CMD_LDD_BD_REG:// Back door to write register 
      dbg_printk(  "psc-ldd: %s: CMD_LDD_BD_REG\n", __FUNCTION__);
      
      bd_index = (uint32_t)((cmd_ldd<<8) | param);//0 to 32767 (1MB)
      
      ret = set_hw_reg(axi_scope_ptr_io, 
                   bd_index,
                   NO_SHIFT,
                  (unsigned int *) arg, param);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }    
      break;
      
    /*case CMD_LDD_FOO: // 0x0F to 0xFF - Commands free actually

      break;*/
    default:
      dbg_printk(  "psc-ldd: %s: NOT COMMAND FOUND\n", __FUNCTION__); 
      break; 
    }  
    break;
  /********************* CTRL US Packet decoding *********************/  
  case CMD_US_GET: 
    switch(cmd_ldd) {
      /********************* CTRL LDD Packet decoding *********************/
      case CMD_LDD_CORE_ENABLE: // Core enable (axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_CORE_ENABLE\n", __FUNCTION__); 
        ret = get_hw_reg(axi_scope_ptr_io, 
                         CTRL_REG_INDEX,
                         CTRL_REG_CORE_ENABLE_MASK,
                         CTRL_REG_CORE_ENABLE_SHIFT,
                        (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }
        break;
        
      case CMD_LDD_SW_RESET: // Sofware reset( axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_SW_RESET\n", __FUNCTION__); 
        ret = get_hw_reg(axi_scope_ptr_io, 
                     CTRL_REG_INDEX,
                     CTRL_REG_SW_RST_MASK,
                     CTRL_REG_SW_RST_SHIFT,
                    (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }
        break;
        
      case CMD_LDD_SINGLE_MODE: // Set single mode (axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_SINGLE_MODE\n", __FUNCTION__); 
        ret = get_hw_reg(axi_scope_ptr_io, 
                     CTRL_REG_INDEX,
                     CTRL_REG_SINGLE_MASK,
                     CTRL_REG_SINGLE_SHIFT,
                    (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }
        break;
        
      case CMD_LDD_TRIGGER_MODE: // Set trigger mode (axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_TRIGGER_MODE\n", __FUNCTION__); 
        ret = get_hw_reg(axi_scope_ptr_io, 
                     CTRL_REG_INDEX,
                     CTRL_REG_TRIGGER_MASK,
                     CTRL_REG_TRIGGER_SHIFT,
                    (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }
        break;
        
      case CMD_LDD_TRIGGER_LEVEL: // Set trigger level (axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_TRIGGER_LEVEL\n", __FUNCTION__); 
        ret = get_hw_reg(axi_scope_ptr_io, 
                     TRIG_LEVEL_REG_INDEX,
                     ALL_1_MASK,
                     NO_SHIFT,
                    (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }
        break;
        
      case CMD_LDD_INT_ENABLE: // Enable interrupts (axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_INT_ENABLE\n", __FUNCTION__);
        ret = get_hw_reg(axi_scope_ptr_io, 
                         CTRL_REG_INDEX,
                         CTRL_REG_INT_ENABLE_MASK,
                         CTRL_REG_INT_ENABLE_SHIFT,
                        (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }    
        break;
        
      case CMD_LDD_INT_ENEBLE_REG: // Set Interrupt Enable Resiter (axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_INT_ENEBLE_REG\n", __FUNCTION__); 
        ret = get_hw_reg(axi_scope_ptr_io, 
                     INT_ENABLE_REG_INDEX,
                     ALL_1_MASK,
                     NO_SHIFT,
                    (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }
        break;
        
      case CMD_LDD_INT_FLAG_REG: // Set Interrupt Enable register (axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_INT_FLAG_REG\n", __FUNCTION__); 
        ret = get_hw_reg(axi_scope_ptr_io, 
                     INT_FLAG_REG_INDEX,
                     ALL_1_MASK,
                     NO_SHIFT,
                    (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }
        break;
        
      case CMD_LDD_ACQ_PERIOD: // Set acquisition period time, this value depends on Zynq frequency (axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_ACQ_PERIOD\n", __FUNCTION__); 
        ret = get_hw_reg(axi_scope_ptr_io, 
                     ACQ_PERIOD_REG_INDEX,
                     ALL_1_MASK,
                     NO_SHIFT,
                    (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }
        break;
        
      case CMD_LDD_RUN_ACQ: // RUN/STOP acquisition (axi-scope-1.0)
        dbg_printk(  "psc-ldd: %s: CMD_LDD_RUN_ACQ\n", __FUNCTION__); 
        ret = get_hw_reg(axi_scope_ptr_io, 
                     CTRL_REG_INDEX,
                     CTRL_REG_RUN_ACQ_MASK,
                     CTRL_REG_RUN_ACQ_SHIFT,
                    (unsigned int *) arg);
        if(ret < 0){
          dbg_printk(  "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }
        break;
        
      case CMD_LDD_BD_REG:// Back door to read register 
        dbg_printk(  "psc-ldd: %s: CMD_LDD_BD_REG\n", __FUNCTION__);    
        /*ret = get_hw_reg(axi_scope_ptr_io, 
                     XXX,
                     XXX,
                     NO_SHIFT,
                    (unsigned int *) arg);
        if(ret < 0){
          dbg_printk( "psc-ldd: %s: get_hw_reg .\n", __FUNCTION__);
        }    */
        break;
              
      /*case CMD_LDD_FOO: // 0x0F to 0xFF - Commands free actually

        break;*/
      default:
        dbg_printk(  "psc-ldd: %s: NOT COMMAND FOUND\n", __FUNCTION__); 
        break; 
      }  
    break;
  /********************* CTRL US Packet decoding *********************/
  case CMD_US_RUN: // RUN/STOP acquisition (axi-scope-1.0)
  case CMD_US_STOP: // RUN/STOP acquisition (axi-scope-1.0)
      dbg_printk(  "psc-ldd: %s: CMD_LDD_RUN_ACQ\n", __FUNCTION__); 
      // Clean fifo.
      fifo_flush(&fifo_str);
      ret = set_hw_reg(axi_scope_ptr_io, 
                   CTRL_REG_INDEX,
                   CTRL_REG_RUN_ACQ_SHIFT,
                  (unsigned int *) arg, param);
      //Activate trigger_shoot (See HW)
      axi_scope_ptr_io[CTRL_REG_INDEX] |= (1 << 7);
      if(ret < 0){
        dbg_printk(  "psc-ldd: %s: set_hw_reg .\n", __FUNCTION__);
      }
      break;
  default:
    dbg_printk(  "psc-ldd: %s: NOT COMMAND FOUND\n", __FUNCTION__); 
    break; 
  }  


  
  
        
  
  //NOTAS
  //template_reg[CTRL_REG_INDEX] |= 0x0008; PONER A 1
    
  //template_reg[CTRL_REG_INDEX] &= ~0x0008; PONER A 0
  
  /*
  core_enable     <= ctrl_reg(0);
  int_enable      <= ctrl_reg(1);
  sw_rst          <= ctrl_reg(2);

  run_acq         <= ctrl_reg(3);
  single_mode     <= ctrl_reg(4);
  trigger_mode    <= ctrl_reg(6 downto 5);
  
  -- Interrupts
  -- edl: Conecta las interrupciones
  int_rqt(0) <= irq_scope;
  int_rqt(1) <= '0';
  int_rqt(2) <= '0';
  int_rqt(3) <= '0';
  */

  dbg_printk(  "psc-ldd: %s: END\n", __FUNCTION__);  
  return 0;
}

/* The device release function that is called whenever the device is 
 * closed/released by the userspace program.
 * @param *inodep - A pointer to an inode object (defined in linux/fs.h).
 * @param *filep - A pointer to a file object (defined in linux/fs.h).
 * @return - It returns 0 if successful.
 */
int driver_release(struct inode *inodep, struct file *filep){
   dbg_printk(  "\n###LDD###: %s.c: %s: device successfully closed.\n",\
              DRIVER_NAME,__FUNCTION__);
              
   return 0;
}


  // Wake up queue head.
int wake_up_interruptible_io(void){
  wake_up_interruptible(&fifo_str.wait_on_rd);
  return 0;
}

  // Wake up queue head.
int clean_irq(uint32_t *base_address){
  base_address[INT_FLAG_REG_INDEX] |= 0x00000001;
  return 0;
}

  // Wake up queue head.
int read_bram(uint32_t *base_address){
  return fifo_put(&fifo_str, base_address);
}
  // Wake up queue head.
int set_axi_scope_ptr(uint32_t *base_address){
  axi_scope_ptr_io=base_address;
  return 0;
}

  // Wake up queue head.
int fifo_init_io(void){
  fifo_init(&fifo_str);
  return 0;
}





