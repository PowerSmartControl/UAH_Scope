/*  psc-ldd.c - The PSC kernel module.
 ******************
 * Edel Diaz Llerena
 * 01/06/2018
 * University of Alcala
 ******************
 * Description:
 * This Driver detects IRQ from CPU and reads/writes in BRAM from user space.
 ******************
 * Change log:
 * v1.0 - Stable.
 * v1.1 - Include trigger_shoot
 ******************
 * Version:
 * 1.1
 ******************
 */

#define VERSION_LDD "1.1"
//#define DEBUG_LDD      // Disable to not show printks

#ifdef DEBUG_LDD
 #define dbg_printk(format, arg...)	\
	printk(format, ## arg);
#else
 #define dbg_printk(format, arg...)
#endif

#include "psc-ldd.h" 
#include "io_user_space_ldd.h"
#include "common_ldd.h" // debug and ldd names
#include "hw_reg_ldd.h"



/* Standard module information, edit as appropriate */
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Edel Diaz - UAH.");
MODULE_DESCRIPTION
    ("psc-ldd - driver to detect IRQ and read/write in I/O address.");
MODULE_VERSION(VERSION_LDD);

/* Parameters */
/* Simple example of how to receive command line parameters to your module.
 * Delete it if you don't need them.
 *  unsigned myint = 0xdeadbeef;
 *  char *mystr = "default";
 *  module_param(myint, int, S_IRUGO);
 *  module_param(mystr, charp, S_IRUGO);
 */
int irq_msg = 0;
module_param(irq_msg, int, S_IRUGO);
MODULE_PARM_DESC(irq_msg, "This flag enable the print message when an interrupt occurs. irq_msg = 0 (default).");





/*Functions*/

/* Interrupt handler. When an interrupt occurs, BRAM is full and we're going to 
 * read all data with read_bram(). Then, it will wakes up queue head.
 * @param irq - It's the numeric value of the interrupt line the handler is servicing..
 * @param *dev_id - It's a generic pointer to the same dev given to request_irq() when 
 * the interrupt handler was registered.
 * @return - The return value of an interrupt handler is the special type irqreturn_t.
 */
static irqreturn_t mymodule_irq(int irq, void *dev_id){

  int ret = 0;
 
//  if(irq_msg){
   dbg_printk(  "\n###LDD###: %s.c: %s: Interrupt detected.\n",\
             DRIVER_NAME,__FUNCTION__);
//  }
   //Clean 61 flag irq of zynq:
  clean_irq(axi_scope_ptr);

  // Read BRAM
  ret = read_bram(axi_scope_ptr);
  if(!ret) {
      //dbg_printk(  "\n###LDD###: %s.c: %s: Event queue overflow.\n",\
             DRIVER_NAME,__FUNCTION__);
  }
  dbg_printk(  "\n###LDD###: %s.c: %s: process %i (%s) awakening the "\
            "readers.\n",DRIVER_NAME,__FUNCTION__,current->pid, current->comm);
            
  // Wake up queue head.
  wake_up_interruptible_io();
  
  return IRQ_HANDLED;
};

/* To load IPs address in Linux Kernel Table Memory. */
/* IMPORTANT */
static int mymodule_probe(struct platform_device *pdev)
{
  struct resource *r_irq; /* Interrupt resources */
  struct resource *r_mem; /* IO mem resources */
  struct device *dev = &pdev->dev;
  struct mymodule_local *lp = NULL;

  int ret = 0;
  dbg_printk(  "\n###LDD###: %s.c: %s: Device Tree Probing.\n",\
             DRIVER_NAME,__FUNCTION__);

  /* Get iospace for the device */
  r_mem = platform_get_resource(pdev, IORESOURCE_MEM, 0);
  if (!r_mem) {
    printk(  "###LDD ERROR###: %s.c: %s: Fail in platform_get_resource.\n",\
           DRIVER_NAME,__FUNCTION__);
    return -ENODEV;
  }
  lp = (struct mymodule_local *) kmalloc(sizeof(struct mymodule_local), GFP_KERNEL);
  lp->irq_allocated = 0;
  if (!lp) {
    printk(  "###LDD ERROR###: %s.c: %s: Fail in kmalloc: cound not allocate "\
                      "psc-ldd device.\n",DRIVER_NAME,__FUNCTION__);
    return -ENOMEM;
  }
  dev_set_drvdata(dev, lp);
  lp->mem_start = r_mem->start;
  lp->mem_end = r_mem->end;

  if (!request_mem_region(lp->mem_start, lp->mem_end - lp->mem_start + 1,
        DRIVER_NAME)) {
    printk(  "###LDD ERROR###: %s.c: %s: Fail in request_mem_region: cound "\
           "not lock memory region at %p.\n",DRIVER_NAME,__FUNCTION__,\
           (void *)lp->mem_start);
    ret = -EBUSY;
    goto error1;
  }
  dbg_printk(  "###LDD###: %s.c: %s: lp->mem_start %p.\n",DRIVER_NAME,\
             __FUNCTION__,(void *)lp->mem_start);
  dbg_printk(  "###LDD###: %s.c: %s: lp->mem_end %p.\n",DRIVER_NAME,\
             __FUNCTION__,(void *)lp->mem_end);

  /* Mapping address IP into table kernel address*/
  lp->base_addr = ioremap(lp->mem_start, lp->mem_end - lp->mem_start + 1);
  if (!lp->base_addr) {
    printk(  "###LDD ERROR###: %s.c: %s: Fail in ioremap: Could not allocate "\
           "iomem.\n",DRIVER_NAME,__FUNCTION__);
    ret = -EIO;
    goto error2;
  }

  /* Allocate mmap area */
  ret = allocate_mmap(lp->mem_start, lp->base_addr);
  if(ret < 0){
    goto error2;
  }
  set_axi_scope_ptr(axi_scope_ptr);

  /* Get interrupt(IRQ) for the device */
  r_irq = platform_get_resource(pdev, IORESOURCE_IRQ, 0);
  if (!r_irq) {
    dbg_printk(  "###LDD###: %s.c: %s: no interrupt found.\n",DRIVER_NAME,\
               __FUNCTION__);
    dbg_printk(  "###LDD###: %s.c: %s: psc-ldd at 0x%08x mapped to "\
               "0x%08x.\n",DRIVER_NAME,__FUNCTION__,\
               (unsigned int __force)lp->mem_start,\
               (unsigned int __force)lp->base_addr);
    return 0;
  }
  dbg_printk(  "###LDD###: %s.c: %s: interrupt from platform got "\
             "correctly.\n",DRIVER_NAME,__FUNCTION__);

  /* Set interrupt handler */
  lp->irq = r_irq->start;
  ret = request_irq(lp->irq, &mymodule_irq, 0, DRIVER_NAME, lp);
  if (ret) {
    printk(  "###LDD ERROR###: %s.c: %s: Fail in request_irq: Could not "\
           "allocate interrupt %d.\n",DRIVER_NAME,__FUNCTION__,lp->irq);
    goto error3;
  }
  lp->irq_allocated = 1;
  dbg_printk(  "###LDD###: %s.c: %s: psc-ldd at 0x%08x mapped to "\
             "0x%08x, irq=%d.\n\n",DRIVER_NAME,__FUNCTION__,\
             (unsigned int __force)lp->mem_start,\
             (unsigned int __force)lp->base_addr, lp->irq);
  return 0;
  error3:
    free_irq(lp->irq, lp);
  error2:
    release_mem_region(lp->mem_start, lp->mem_end - lp->mem_start + 1);
  error1:
    kfree(lp);
    dev_set_drvdata(dev, NULL);
    return ret;
};

/* To free IPs address from Linux Kernel Table Memory. */
static int mymodule_remove(struct platform_device *pdev)
{
  /*IOMEM and IRQ*/ 
  struct device *dev = &pdev->dev;
  struct mymodule_local *lp = dev_get_drvdata(dev);
  if (lp->irq_allocated == 1 ){
    free_irq(lp->irq, lp);// irq
  }
  release_mem_region(lp->mem_start, lp->mem_end - lp->mem_start + 1);//iomem
  kfree(lp);//iomem
  dev_set_drvdata(dev, NULL);// device
  return 0;
};

/* Assignment of platform device functions to driver
 * When an IP from Devicetree is register, mymodule_probe() is executed and
 * when is unregister with mymodule_remove().
 */
static struct platform_driver mymodule_driver = {
  .driver = {
    .name = DRIVER_NAME,
    .owner = THIS_MODULE,
    .of_match_table	= mymodule_of_match,
  },
  .probe  = mymodule_probe,
  .remove = mymodule_remove,
};

/* Assignment of I/O access functions to driver*/
static struct file_operations fops = {
  .owner    =  THIS_MODULE,
  .read     =  driver_read,
  .write    =  driver_write,
  .unlocked_ioctl = driver_ioctl,
  //.ioctl    =  driver_ioctl,
  .open     =  driver_open,
  .release  =  driver_release,
};

/* The LKM initialization function
 * The static keyword restricts the visibility of the function to within this C 
 * file. The __init macro means that for a built-in driver (not a LKM) the 
 * function is only used at initialization time and that it can be discarded and
 * its memory freed up after that point.
 * @return - It returns 0 if successful.
 */
static int __init mymodule_init(void)
{
  /*Welcome message*/
  printk(  "###LDD###: %s.c: %s: VERSION %s.\n",DRIVER_NAME,__FUNCTION__,VERSION_LDD); 
  dbg_printk(  "###LDD###: %s.c: %s: Module parameters were irq_msg "\
             "= %i\n",DRIVER_NAME,__FUNCTION__,irq_msg); 
  
  /* Init waitqueue_head */ 
  fifo_init_io();
  
  /* Get Character device */
  // Try to dynamically allocate a major number for the device 
  //(more difficult but worth it).
  majorNumber = register_chrdev(0, DEVICE_NAME, &fops);
  if (majorNumber<0){
    printk( "###LDD ERROR###: %s.c: %s: Failed to register a major "\
           "number.\n",DRIVER_NAME,__FUNCTION__); 
    return majorNumber;
  }

  /* Register the device class */
  mymoduleClass = class_create(THIS_MODULE, CLASS_NAME);
  // Check for error and clean up if there is
  if (IS_ERR(mymoduleClass)){                
    unregister_chrdev(majorNumber, DEVICE_NAME);
    printk( "###LDD ERROR###: %s.c: %s: Failed to register device "\
           "class.\n",DRIVER_NAME,__FUNCTION__);
    // Correct way to return an error on a pointer
    return PTR_ERR(mymoduleClass);          
  }

  /* Register the device driver */
  mymoduleDevice = device_create(mymoduleClass, NULL, MKDEV(majorNumber, 0), NULL, DEVICE_NAME);
  // Clean up if there is an error
  if (IS_ERR(mymoduleDevice)){     
    // Repeated code but the alternative is goto statements  
    class_destroy(mymoduleClass);          
    unregister_chrdev(majorNumber, DEVICE_NAME);
    printk( "###LDD ERROR###: %s.c: %s: Failed to create the device.\n"\
           ,DRIVER_NAME,__FUNCTION__);  
    return PTR_ERR(mymoduleDevice);
  }
  
  /* Create character device */
  cdev_init(&c_dev, &fops);
  if (cdev_add(&c_dev, majorNumber, 1) == -1) {
    printk( "###LDD ERROR###: %s.c: %s: Create character device "\
           "failed.\n",DRIVER_NAME,__FUNCTION__);  
    device_destroy(mymoduleClass, majorNumber);
    class_destroy(mymoduleClass);
    unregister_chrdev_region(majorNumber, 1);
    return -1;
  }
  dbg_printk(  "###LDD###: %s.c: %s: LDD registered correctly with "\
             "major number %d.\n",DRIVER_NAME, __FUNCTION__, majorNumber); 
        
  /* Register driver*/
  return platform_driver_register(&mymodule_driver);
};

/* The LKM cleanup function
 * Similar to the initialization function, it is static. The __exit macro 
 * notifies that if this code is used for a built-in driver (not a LKM) that 
 * this function is not required.
 */
static void __exit mymodule_exit(void)
{
  /*Character device*/
  // Remove the device
  device_destroy(mymoduleClass, MKDEV(majorNumber, 0)); 
  // Unregister the device class
  class_unregister(mymoduleClass);  
  // Remove the device class
  class_destroy(mymoduleClass);  
  // Unregister the major number
  unregister_chrdev(majorNumber, DEVICE_NAME);  
  
  platform_driver_unregister(&mymodule_driver);
  printk(  "###LDD###: %s.c: %s: LDD closed.\n", DRIVER_NAME, __FUNCTION__);  
};
/* A module must use the module_init() module_exit() macros from linux/init.h, which
 * identify the initialization function at insertion time and the cleanup function (as
 * listed above)
 */
module_init(mymodule_init);
module_exit(mymodule_exit);
