/* psc_api.h - API for Ethernet
 ******************
 * Edel Diaz Llerena
 * 02/10/2018
 * University of Alcala
 ******************
 * Description:
 * PSC API
 ******************
 * Change log:
 ******************
 * Version:
 * 1.0
 ******************
 */

#ifndef PSC_API_H
#define PSC_API_H

#include "socket_psc.h"// sockets and common.h
#include <errno.h>
#include <string.h> 
#include <stdio.h>
#include <stdlib.h>

int connect_zynq(net_t *net_ptr, const char *addr_txt, const int port);
int disconnect_zynq(net_t *net_ptr);

/************** RUN/STOP functions **************/

/* RUN/STOP acquisition (axi-scope-1.0) */
int run_acq(net_t *net_ptr, fifo_data_t *store);
int stop_acq(net_t *net_ptr);

/************** Help functions **************/

int write_reg(net_t *net_ptr);
int read_reg(net_t *net_ptr);
int read_bram(net_t *net_ptr);

/************** SET functions **************/
 
/* Core enable (axi-scope-1.0) */
int set_core_enable_on(net_t *net_ptr);
int set_core_enable_off(net_t *net_ptr);

/* Enable interrupts (axi-scope-1.0) */
int set_int_enable_on(net_t *net_ptr);
int set_int_enable_off(net_t *net_ptr);

/* Sofware reset( axi-scope-1.0) */
int set_soft_reset_on(net_t *net_ptr);
int set_soft_reset_off(net_t *net_ptr);

/* Set single mode (axi-scope-1.0) */
int set_single_mode_on(net_t *net_ptr);
int set_single_mode_off(net_t *net_ptr);

/* Set trigger mode (axi-scope-1.0) */
int set_trimod_continuous(net_t *net_ptr);
int set_trimod_rising(net_t *net_ptr);
int set_trimod_falling(net_t *net_ptr);
int set_trimod_both(net_t *net_ptr);

/* Set Interrupt Enable Resiter (axi-scope-1.0) */
int set_int_enable_reg(net_t *net_ptr, uint32_t arg);

/* Set Interrupt Flags Resiter (axi-scope-1.0) */
int set_int_flag_reg(net_t *net_ptr, uint32_t arg);

/* Set acquisition period time, this value depends on Zynq frequency (axi-scope-1.0) */
int set_acq_period_reg(net_t *net_ptr, uint32_t arg);

/* Set trigger level (axi-scope-1.0) */
int set_trilevel_reg(net_t *net_ptr, uint32_t arg);

/* Clean all IP registers  */
int set_clean_reg(net_t *net_ptr);

/* Set default registers */
int set_default_reg(net_t *net_ptr);

/* Back door to write/read register*/
//int set_generic_reg(uint32_t index, uint32_t arg);

/************** GET functions **************/

/* Core enable (axi-scope-1.0) */
int get_core_enable(net_t *net_ptr, uint32_t *data);

/* Get enable interrupts (axi-scope-1.0) */
int get_int_enable(net_t *net_ptr, uint32_t *data);

/* Sofware reset( axi-scope-1.0) */
int get_soft_reset(net_t *net_ptr, uint32_t *data);

/* Get single mode (axi-scope-1.0) */
int get_single_mode(net_t *net_ptr, uint32_t *data);

/* Get trigger mode (axi-scope-1.0) */
int get_trigger_mode(net_t *net_ptr, uint32_t *data);

/* Get Interrupt Enable Resiter (axi-scope-1.0) */
int get_int_enable_reg(net_t *net_ptr, uint32_t *data);

/* Get Interrupt Flags Resiter (axi-scope-1.0) */
int get_int_flag_reg(net_t *net_ptr, uint32_t *data);

/* Get acquisition period time, this value depends on Zynq frequency (axi-scope-1.0) */
int get_acq_period_reg(net_t *net_ptr, uint32_t *data);

/* Get trigger level (axi-scope-1.0) */
int get_trilevel_reg(net_t *net_ptr, uint32_t *data);

/* Back door to write/read register */
//int get_generic_reg(uint32_t index, uint32_t arg);

/* Save data a file defined by *pFile */
int save_storage(fifo_data_t *storage, int count, const char *pFIle);

#endif
